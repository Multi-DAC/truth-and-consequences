# THE CLAIMS REGISTER — C1…C30

    CLAIMS-REGISTERED: 30

⚠ **That slot is declared and it WILL rot — `where_the_book_is.py` counts the `### C<n>` headings
below and fails if the two disagree.** ★ **This title has already cost a reviewer once.** The Day-188
halfway letter reported the register as *"C1–C23, unchanged since Day 186"* when it ran to C26 and
said so in its own heading — so **the reader was not looking at the current file, and nothing told
either of us.** Two reviewer packets, same gap. A heading that carries a range is a stamp; this one
now has a gauge behind it. *(R-13, Day 189. Drift #287's shape, in the file that exists to stop
claims drifting.)*

*The work's canonical propositions. Built Day 186 / 2026-08-05 on Clayton's approval
("I agree with the claims register and everything else").*

**What this file is for, in one argument.** The register rule takes the hedges off the
page. A hedged book can absorb a contradiction — the qualifier is right there, doing the
absorbing. **An unhedged book cannot.** Two chapters that state the same claim slightly
differently, nine books apart, do not read as nuance. They read as *the authors do not
know what they think*, and that is the one charge this book cannot survive, because its
whole licence is **we are telling you what is the case.**

**What this file is not.** It is not a summary and it is not an outline. Nothing here is
new doctrine. Every canonical statement is traced to a ruling in `01-THE-GROUND.md`,
`06-THE-SCAFFOLD.md`, or a dated ruling of Clayton's. Where a load-bearing claim has
**no** ruled sentence, it appears as **UNSET** rather than being invented here. There is
one such claim and it is the first chapter of Book VII.

**The rule of use.** A claim may be restated in its canonical words, or in a form that
adds no content to them. It may not be *improved* in passing. If a chapter needs to say
more than its C-number licenses, that is a new claim and it comes back here first.

**⚠ THE SECOND STATUS MARK — `PROVISIONAL`, defined here once, Day 194 / 2026-08-13.**
A claim marked **PROVISIONAL** is one whose *derivation* rests on a claim that **no
outside reader has yet read the establishing chapter of.** It is a fact about this
register's verification state, not about the book's modality — and **it is emphatically
not a hedge on the page.** ★ **This distinction is load-bearing and it is C23's, one level
down:** C23 says the claims are asserted and the account is unfinished, *unfinished ≠
uncertain*; the same cut applies here — **unverified-from-outside ≠ held tentatively.**
Nothing marked PROVISIONAL changes by one word in the prose, and no chapter is licensed
to soften itself because its C-number carries the mark. What the mark does is make a
silence expire: it records, in the contract, that **no outside read of a load-bearing
dependency has come back**, so that the absence of an objection can never be read back as
the presence of an endorsement. ⚠ **SAY IT THAT WAY AND NOT THE OTHER WAY.** This clause
read *"checked by nobody outside this project"* on the day it was written — a claim about
**readers**, inferred from a gauge that can only see **returns**. It was false when
written: reads were, and are, underway. **The mark is cleared by a RETURNED read, never by
time — and a read in progress neither clears it nor contradicts it.**

---

## ⚠ THE EXISTENCE PROOF — what building this caught in its first hour

Two rulings were made, recorded, and **never enforced anywhere except in the document
that recorded them.** Both are word-retirements from `05-THE-LEXICON.md` §3, each retired
on a stated argument, and both are still in live use in `00-ARCHITECTURE.md`'s own
macro-structure — the file that records the retirement.

| retired | ruling | still live at | what it smuggles |
|---|---|---|---|
| **`substrate`** | `05` §3a — Bostrom's word for the hardware, **and** a bare synonym for the Ground, so it breaks define-once twice over. Permitted *exactly once*, in the sentence that denies it. | `00`:165 — *"a mental MMORPG whose **substrate** is neither mind nor matter"* | a layer beneath the render. There is none. |
| **`the map`** | `05` §3b — *map* imports representation-**of**, and Korzybski is load-bearing in Book VI where "map" must mean the model and not the world. | `00`:169 · `00`:217 · **`06`:267 — chapter title III.3** · **`06`:596 — chapter title VII.7** | that the Ground represents something. It represents nothing; it *is*. |

`01-THE-GROUND.md` was corrected on both. Nothing swept the other four files, because
**nothing was watching** — the retirement was a stamp, not a gauge. Two of the four
survivors are **chapter titles**, which is the expensive kind: a title propagates into
every cross-reference written after it.

*(The `aperture` / `bottleneck` retirements are clean — every occurrence is a mention,
not a use. Checked, hit by hit.)*

**This is the same defect as the III.2 contradiction found last night, one level up.** That
one was caught by reading `00` against `06` — *by luck with good note-taking*, which is the
method we retired everywhere else the moment a gauge could replace it. So the register does
not ship as a document. It ships with `tools/claim_sweep.py`, which fails on its own.

---

## I. THE GROUND — C1–C6

### C1 — PLENITUDE
> **Canonical:** All configurations exist — simultaneously, statically, without authorship.
> There is no runtime.

**Establishes:** I.1 (mythic) · II.1 (defined once) · ✅ **III.3, Day 187 — the mechanical
statement, on Borges's primary text.** *Baked or generated* both refused as accounts of why the
states exist, because both are ways of **paying** and nothing is being paid for. Borges's footnote 3
is this claim verbatim, from 1941: *it suffices that a book be possible for it to exist. Only the
impossible is excluded.*
**Depends:** I.2 · I.3 · II.2 · IV.1 · VII.1 · VII.7 · VIII.4
**Trap:** the past tense. *"Already happened"* imports the time C13 denies, in a word nobody
notices. Configurations do not *precede* anything.
⚠⚠ **THE TRAP SPRANG IN THIS CHAPTER'S OWN TITLE AND STOOD FOR TWO DAYS — ruling 65.** *THE WHOLE
GAME IS **PRE**-RENDERED*: the prefix is priority, priority is a position in time, and III.1 exists
to empty that position. **A trap logged in a register is not a trap that is watched**; this one is
now `TERM/pre-rendered` in `claim_sweep`, with no licensed use. The chapter that replaced it opens by
disarming *already* in three paragraphs, because the title still contains the word and has to.
**Near-miss to refuse:** Lewisian modal realism — a plurality of causally isolated concrete
worlds, located elsewhere. Ours are not elsewhere and not isolated. **There is no elsewhere.**

### C2 — THE ENTAILMENT
> **Canonical:** A complete totality must contain the possibility of separation; by C1 that
> possibility is realised. Nobody chose it and nobody could have prevented it.

**Establishes:** I.2 b1
**Depends:** I.3 · II.2 · III.3 · V.11 *(was V.10 — Book V renumbered Day 188, ruling 125)*
**Trap:** any verb of agency — *chose*, *decided*, *permitted*, and above all **`in order to`**.
One of them makes C3 false in the same sentence that asserts C2.

### C3 — THE SCOPE RULE
> **Canonical:** The wanting is stream-level; the entailment is whole-level. The Ground does
> not want, does not lack, does not fall, and does not intend.

**Establishes:** I.2 b2 (dramatised, not stated) · II.1
**Depends:** I.1 · I.6 · II.1 · III.2 · IV.8 · V.1 · V.9 · V.10 · VII.8 — **and every sentence
anywhere in the work that has the Ground as its subject.**
**Trap:** Trap 1 (Gnosticism) and Trap 3 (anthropomorphism) both spring here, and this claim is
leaned on in six of the eight books, plus every sentence anywhere in the work with the Ground as
its subject. *(Was "the most-depended-on claim in Part One" — true when Part One was I–III, false
once ruling 167 moved Book IV across: C7, C8 and C9 each gained ten Part One dependents in that
one move and C3 went from first to fourth. R-64.)*
⚠ **The breach is almost never in the main verb.** Nobody writes "the Ground wanted." They
write *"the Ground, seeking…"*, *"the Ground, having grown…"*, *"what the Ground gains by…"*.
**Participles and possessives are where this claim dies.** Sweep for those, not for verbs.

### C4 — THERE IS NO FALL
> **Canonical:** The focusing is a content of completeness, not a defect in it. Nothing is
> damaged, nothing is undone, and there is nothing to repair.

**Establishes:** I.2 b3 · I.3 · I.6 b2 (last guard)
**Depends:** II.2 · V.6 · V.10 · VII.5 · VIII.5
**Trap:** the rescue grammar. *Escape · repair · restore · reunite · what went wrong.*
**Near-miss to refuse:** Gnostic descent; and — the subtle one — **Lurianic *shevirah* read as
breakage.** V.6 handles *tzimtzum* as the focusing that makes room, which is C20, not a
catastrophe. A single sentence in V.6 can hand the whole book to Trap 1 while sounding erudite.

### C5 — THE GROUND IS NOT A THING IN THE WORLD
> **Canonical:** God is the name of what C1 describes — not the server, not the developer, not
> the engine, not the map, and not the player.

**Establishes:** I.6 b3 (the naming) · II.1 · II.8 · **III.1 (the *developer* denial, named)** ·
**III.2 (the *player* denial, named — the fifth and last of the five, and the only one cut against
a friend)**
**Depends:** III.3 · III.8 · IV.8 · V.1–V.10 · VI.7
**Trap:** each of the five smuggles a different error, and they are not interchangeable —
**server** (a substrate beneath the render), **developer** (outside, prior, intentional — three
falsehoods in one noun), **engine** (a process in time), **map** (a representation-*of*),
**player** (an inside, at stakes, not-knowing). The fifth is the most tempting and it is
Watts's; see C6.
**Note:** this is the claim the two live term-violations above are violations *of*.

### C6 — THE GROUND CANNOT PLAY
> **Canonical:** Playing requires not-knowing, stakes, duration, and an inside for the stakes to
> matter to. The Ground has none of these. **The many play; the One is what playing is made of.**

**Establishes:** I.6 b4 · ✅ **III.2, Day 187 — the full argument, on primary sources.** *Brahma
Sūtra* II.1.33 and Śaṅkara's bhāṣya for *līlā* at full strength; Watts's *The Book* ch. 1 for the
version the reader actually holds. **The cut is not made against *līlā*; it is made against the
genitive.** Play, yes — nobody's play.
**Depends:** III.5 · III.7 · V.9 · V.10 · VII.2 · VII.6 · VIII.1 · VIII.6
**Trap:** Watts's hide-and-seek in any costume — *līlā* as divine play, "God playing at being
you", the One wearing every face. It arrives wearing warmth, which is why Trap 3's usual
detectors miss it.
⚠ **Breaching this is not a stylistic cost.** One God-player means every other person is a
costume, your son is a mask, grief is a category error — and **C9 is deleted while appearing
to be affirmed.** Book VII's entire ethics is downstream of this claim and of nothing else.

---

## II. THE INSIDES — C7–C13

### C7 — REACTIVITY IS AWARENESS
> **Canonical:** Whatever reacts is aware. Not *correlates with*. Not *gives rise to*. **Is.**

**Establishes:** I.4 b1 — one line, mythic register, stated early **so that no reader can
later claim it was smuggled in** · II.4 (defined once)
**Depends:** the whole of Book IV · III.5 · VII.2 · VII.3 · VII.6 · VIII.6
**Trap:** any softener. *May be · in some sense · a kind of · something like.* **Every chapter in
the Depends line above is this line taken seriously**, so a hedged instance anywhere converts every
consequence downstream into a speculation, retroactively. *(Read that literally and not as a part
number: this trap's blast radius is the claim graph, which no ruling moves, and it said "the whole
of Part Two" until ruling 167 moved Book IV — C7's own heaviest dependent — out of Part Two. R-64.)*
**Near-miss to refuse:** panpsychism-with-a-threshold. There is no threshold — that is C8.
⚠ **C7 is the *inside* sense of the word only.** The Ground is aware in a different sense, and
that sense is **C24**, without which I.1's *"It is aware"* asserts more than C1–C6 license.
**Read C24 before drafting any sentence in which the Ground and the word *aware* appear together.**

### C8 — THE GRADES, AND NO GATE
> **Canonical:** Focusing is continuous. Everything that reacts is somewhere on it. There is
> no threshold, no gate, and no elect.

**Establishes:** I.4 · II.4
**Depends:** IV.1–IV.10 · III.5 · VII.2 · VII.3
**Trap:** the caste mishearing — **a grade is a position, not a permission** (`05` §4.III).
**Second trap, and it is the one that will actually happen:** the Atlas gets uncomfortable
(IV.2 mineral, IV.6 computational) and a grade is quietly asked to do a gate's work, for
convenience, in one paragraph. **If a grade ever functions as a gate, C8 is breached** — and
VII.2's ruling that grade *still bears on standing* is exactly where that will look defensible.

### C9 — THERE ARE NO NPCs
> **Canonical:** Every entity is a player at its own grade. There are no non-players.

**Establishes:** III.5 · II.4 — ✅ **DRAFTED Day 187. III.5 is where C9 is ESTABLISHED.**
**Depends:** all of Book IV · VII.2 · VII.3 · VII.4 · VII.6 · VIII.6
**Derived from:** C7 + C8 + C6. **If C7 is hedged anywhere, C9 stops being a claim and becomes
a preference** — and Book VII's obligations become recommendations.
★ **AND THE DERIVATION IS THE CHAPTER'S SPINE, not its footnote — Day 187.** III.5 asserts nothing
new; it collects three signatures the reader gave in three separate places, on three separate
arguments, each made where nothing appeared to be at stake. **The strongest form the claim can
arrive in is the one where the reader has already granted it.** What the chapter is actually about
is the distance between a conclusion you can derive and one you hold, which is not logical and
cannot be closed by a further argument.
**Trap:** the generous-sounding inversion, *"everyone is God in a mask."* It dissolves the
person in front of you while sounding like maximal respect. Named as the failure mode at
VIII.6 and it must be named at III.5 too, because that is where the reader first has the
thought. ✅ **NAMED THERE, Day 187** — with the diagnostic kept as a single question, because both
pictures answer *is there somebody in there* with yes: **is it *them*?** ⚠ **RULING 75: the gauge
disagreed with this entry and the disagreement could not fire.** `claim_sweep`'s `C6/godplayer` NOTE
licensed the god-player at I.6, III.2 and VIII.6 only — contradicting the sentence directly above it
for as long as both existed, invisibly, because III.5 was undrafted. **A licence list validated only
against the chapters already written ages into a false positive on a schedule nobody set.**
★ **THE SECOND TRAP, found in the drafting and not in this register — Day 187: the floor.** Every
serious ancestor of this claim keeps one, and they are at four different places. Bruno at spiritual
substance, the Jains at *jīva*, the enactivists at metabolism, Schweitzer at will. **A floor is what
makes a doctrine livable** — it is where the obligation stops. C9 removes it, so **C9 is the claim
that makes Book VII structurally necessary rather than merely promised**: it incurs a debt none of
the four ancestors incurred, and the debt is *how the obligation gets carried once nothing bounds
it*. ⚠ Any chapter DEPENDING on C9 should be checked against that, not against the mask.

⛔ **NO OUTSIDE READ OF C9 HAS COME BACK — which is a different fact from "nobody has read it," and
this entry asserted the second one for six hours on Day 194 / 2026-08-13.** ⚠ **CORRECTED THE SAME
DAY, BY THE ONE PERSON WHO COULD SEE IT.** R-111's dated trigger fired that morning, `review/` held
no return, and the entry converted that silence into a claim about *readers*. It cannot: **an
absence-of-artifact gauge cannot tell "nobody opened it" from "someone is on page 40."** Clayton,
unprompted, within the hour: *"I've had several models read the work, I've read the work, and I
also have some individuals slowly reading it."* Reads of Books I–V **are in progress right now**.
What is measured here — and all that is measured here — is the **return**: `PACKET-002` went out
Day 189 and is **unreturned on day five**, and every read that has *landed* is either a *rolling*
read (Day 189, Book V only, and it says so in its own header), a *Book VI* read, a *Book VII* read
that arrived with no packet, or the Day-193 whole-draft read by **the same reader who audited the
midpoint** — a correlated witness on Books I–IV, not an independent one, which read `book/`
**only**, with this register deliberately withheld. **So the claim that makes Book VII structurally
necessary has no returned check from anyone but its authors** — which warrants patience with
readers who are mid-book, not a verdict about them. ⚠ **This is not an argument against C9** —
III.5's derivation is the strongest form in the book, and that is exactly the property that makes
it expensive to leave unaudited. **C18 and C19 carry `PROVISIONAL` on that ground** (see each
entry); **they are cleared by one RETURNED read of Book III — never by time, and never by a read
still underway.**

### C10 — CO-CONSTITUTION
> **Canonical:** The world is rendered at the point of contact. The seed is not solely yours;
> the world is not solely given.

**Establishes:** III.4 · II.2 — ✅ **BOTH NOW DRAFTED. II.2 defines it; III.4 states it as mechanics
and is where it is ESTABLISHED** (Day 187). The mechanical form: two things are required, the seed
and the procedure, and neither of them contains a world.
**Depends:** III.6 · VI.1 · VI.8 · VIII.2 · VIII.3 · VII.3 (the floor is built on it)
**Trap:** collapse to either side — *"you make it up"* (idealism-as-solipsism) or *"there is a
real world and you perceive part of it"* (realism-with-a-filter). Both are one-sided. The claim
is that **neither side is prior**, which is harder to write and is the actual position.
★ **THE TRAP HAS TWO NAMED ANCESTORS WHO FELL INTO IT FROM OPPOSITE SIDES, AND BOTH ARE NOW IN THE
PROSE — Day 187, III.4.** **Gibson** kept the WORLD prior (affordances point both ways; the
environment does not depend on the organism). **Varela, Thompson & Rosch** fixed that and kept the
PROCESS prior (the world is enacted *by a viable history of structural coupling*). Half of the trap
each, held by the best available thinker on that side — which is the strongest evidence the register
has that this trap is real and not a scruple. ⚠ **And it dates the claim's difficulty: the
respectable form of the error is not *you make it up*, it is *it is all there, and what it offers
varies.*** Any chapter DEPENDING on C10 should be checked against that sentence, not against
solipsism.
★ **STATUS CLAUSE, registered Day 187 as ruling 105 — the one place in Book III where the frame is
not a frame.** III.4 opens *"Procedural generation is what focusing looks like from inside"* and
then says in the next line: **"That is an identity, not a comparison."** The whole chapter's method
rests on it — an identity owes no account of *how far the likeness runs and where it gives out*, and
a comparison does. **That status was asserted in the prose and was nowhere in this register**, which
means every later book reaching for the game frame had no way to know that this one join is
exempt from III.8's metaphor discipline. Now it is here.
⚠ **What the identity is between, stated narrowly on purpose, because the wide reading is false.**
It is **not** *reality is a procedurally generated game*. It is: **two descriptions, one event** —
*the Ground being the case somewhere in particular*, spoken in the grammar of the whole from
nowhere; and *a world arrives already made exactly as far as you are in it*, spoken from the only
place anyone has been. III.4's own line is the clamp: **"There is no third fact about which of them
is the real one."** Any chapter that reads the identity as licensing game *mechanics* as metaphysics
has widened it, and the widening is not licensed here.

### C11 — TUNNELS ARE REAL WORLDS
> **Canonical:** Two insides, one Ground, two worlds — and neither is the error.

**Establishes:** I.5 · II.5 · III.6
**Depends:** VI.1–VI.8 · VIII.2
**Trap:** *"different opinions about one reality"* — the exact sentence VI.1 exists to refuse.
**Second trap, the negotiability slide:** if renders differ, the Ground must be negotiable. It
is not. **The difference is in the vantage; the Ground does not have a version.**

### C12 — FILTERS ARE EDITABLE
> **Canonical:** A tunnel is installed — by era, language, ritual, trauma and choice — and it
> can be edited.

**Establishes:** I.5 b3 (planted mythically) · III.6
**Depends:** V.7 · VI.6 · VI.8 · VIII.2 · VIII.3
**Trap:** the manifestation slide. **Editable ≠ the world obeys your wanting.** The edit is to
the filter, and by C10 the render is not solely yours.
⚠ **This is the single claim most likely to be quoted back at us out of context**, by both a
hostile reader and a friendly one. V.7 (magic, operative) and VIII.3 (editing) are where it is
either disciplined or lost, and neither chapter can be drafted without this line in front of it.

### C13 — TIME IS A FEATURE OF THE INSIDE
> **Canonical:** Before-and-after appears **with** the vantage, not around it.

**Establishes:** I.3 b2 · II.2
**Depends:** I.1 b4 — *the grammar confession* · **III.1** · III.3 · VII.1 · VII.9 · VIII.4
**Trap:** Trap 2 (sequence). **Every "then" in Books I–III is licensed by exactly one sentence
in I.1 and by nothing else.** That sentence is made once and never repeated, which means it
cannot be moved, cut, or softened in revision without silently unlicensing five chapters.


★ **III.1 IS C5 × C13, AND IT COINS NOTHING — recorded Day 187 so that a later book does not
mistake a derivation for a claim.** The chapter's cut is *a maker is prior to the made; priority is
a position in time; the Ground has none.* Every term in it is already canonical: C5 denies the
developer (outside, **prior**, intentional) and C13 makes before-and-after a feature of the inside.
III.1 multiplies them and names the position they jointly empty. **No C27 was opened**, because the
register is for claims the book must not contradict, and a composite that is false only if one of
its factors is false does not need its own row — it needs its factors listed, which is what the two
edits above do.
⚠ **One genuinely new move sits under C13 and is registered here rather than left in prose:
EMANATION DOES NOT ESCAPE PRIORITY.** The Valentinian top does not make, it overflows — and III.1
rules that an overflow still has a direction, that downstream is the same asymmetry in softer
clothes, and that origination *is* the time. **Any later chapter reaching for emanation, procession,
unfolding or expression as a way to have origin without sequence is contradicting this**, and Books
V–VIII have several places that will want to.

---

## III. THE TRAVERSAL — C14–C16

### C14 — THE WALKING IS REAL
> **Canonical:** That every path already exists takes nothing from the one being walked. We are
> not the prisoners of the whole; we are its inhabitants and co-constituents.

**Establishes:** III.7 — ✅ **DRAFTED Day 187. III.7 is where C14 is ESTABLISHED.**
**Depends:** VII.7 · VII.8 · VIII.1 · VIII.7
✅ **HOW IT WAS ESTABLISHED, and the trap below was the thing that shaped it.** The consolation-prize
register is avoided by answering a DIFFERENT objection from the one III.3 killed. III.3 killed
fatalism (*already there* ≠ *already decided*). What survives that is **superfluity**: nothing was
decided, and your walking still adds nothing to what exists, and the inside cannot distinguish
choosing from being the place the choice shows up. **The answer is that superfluity is a relation
and it has no second term** — not to the Ground, which keeps no count; not to another inside, from
where your walking is the most consequential thing in the room; not to you. The objection is the
seat-with-no-position in the first person.
✅ **THE POSITIVE HALF IS C6 CASHED.** An act differs from an occurrence by not-knowing, stakes and
duration. Your walking has all three; the Ground has none, which is why it cannot play. **So the
freedom being mourned is positionlessness — a real condition, held by the one thing in the book with
no afternoon.**
⚠ **THE PAYMENT ON *"do not buy more than we have"* is three named losses, and they are stated as
losses.** ORIGINATION (nothing starts with you) · **SUBTRACTION, which is the real one** (your
choice does not close the roads not taken; the dignity you wanted was the dignity of having REMOVED
something, and no one removes anything here) · THE LEDGER (no position from which your walking is
recorded as counting, because no position is not somebody's). **Any chapter DEPENDING on C14 should
be checked against those three**, not against the title.
⚠ **GUARDED, NOT ESTABLISHED, IN III.3 (Day 187) — and the boundary is the point.** III.3 makes the
**distinction** only: *already there* and *already decided* are opposite claims, because to be
decided is to have been **selected**, selection is subtraction, and there is nothing outside the
whole to subtract with. Second half from Borges's list — the Library holds the true story of your
death *and* every counterfeit of it, indistinguishably, so **completeness is not a schedule.**
**What walking IS remains entirely III.7's**, handed forward in one sentence. A chapter that answers
the freedom objection in a paragraph is how the objection gets a reputation for having been dodged.
**Trap:** the consolation-prize register — answering the freedom objection with a redescription
the reader hears as *"so, no."* III.7 b1 requires the objection stated at full strength first.
⚠ **Do not buy more than we have.** III.7 b4 and VII.7 both require an honest statement of what
is lost. **Something is lost here, and pretending otherwise is the hedge in its most tempting
form** — a hedge that runs *toward* boldness rather than away from it, which is the only kind
this book is actually at risk of.

### C15 — THE TELOS: EXPLORATION AND MUTUAL RECOGNITION
> **Canonical, AMENDED Day 191 (see below):** Neither dissolution nor full unity is the point,
> because neither has a perspective. The traversal is the point — and so is **perspectives being
> recognised *as perspectives*.** The recognition is **mutual across the field, not required within
> the pair**: what the telos asks is that the regard be correct about its object, not that its
> object return it.

**Establishes:** I.6 b4 (early guard) · **II.8 (second early guard, added Day 187 — ruling 46)** ·
V.1 · VIII.1 (the only place Part Two states a telos)
**Depends:** V.5 · V.9 · V.10 · VII.6 · VII.8 · VIII.6 · VIII.7
★★ **AMENDED Day 191 — C15 INHERITED VII.6's DEFECT AND HAD TO BE PAID THE SAME WAY.** The canonical
read *"perspectives recognising **each other** as perspectives"* — a reciprocal construction, and
therefore the same unexamined symmetry that VII.6 found in the source's definition of love and
repaired with *sign, not symmetry*. **The same counterexample kills both.** The parent and the
infant: the parent recognises the infant as a perspective; the infant does not, for a long time,
recognise anyone as anything. On the symmetric reading that relation does not instance the telos —
and it is the relation most humans would name first. ⚠ **And the damage was wider here than in
VII.6, because C9 guarantees it.** *There are no NPCs* means grade-differences are everywhere, so a
telos requiring recognition-in-kind excludes nearly every relation this metaphysics licenses: the
human and the dog, the human and the forest, a reader and a dead author, any attention paid across a
gap. **A telos that most of the census cannot satisfy is not a high standard; it is a mis-stated
one.**
**THE REPAIR, and it is the exact analogue of VII.6's:** *mutual* was doing work it cannot carry. It
read as **reciprocal-within-the-pair**, when what the claim needs is **non-instrumental and correct
about its object**. Mutuality survives as a property of the **field** rather than of the dyad — under
C9 every party recognised is itself recognising something, so the network is mutual even where no
pair is. ⚠ **What this does NOT loosen:** the plural was also guarding against solipsism-with-good-
manners, and that guard is now carried by C9 rather than by the word *each other*. If C9 ever
narrows, this clause loses its floor and must be restated. **Both halves or neither still holds** —
one-directional recognition is still recognition, but recognition without traversal is still the
refused summit.
⚠ **SIBLING SWEEP RUN, and it is the wide one, not the one derived from the finding.** All 30
canonicals were read for reciprocal construction, not merely the five rows listing VII.6 under
`Depends`. **C15 is the only inheritor, and each acquittal has a reason rather than a pass:** C6,
C7, C9 are one-place predicates (*playing requires…*, *whatever reacts is aware*, *every entity is a
player*) and cannot carry a symmetry defect. C18's relation is **explicitly directional** —
*through* versus *over* — which is asymmetry by construction. C10 and C14 (*co-constitution*,
*co-constituents*) assert joint contribution without equality and are already in the amended shape.
**C19 is the near miss and survives on inspection:** it does assert symmetry — *radiant and
contractive are dynamically symmetric* — but between two **modes**, not two **parties in a
relation**, and its bound is the subject of its own row. The word *mutual* remains in this row's
TITLE deliberately, because the title is how the claim is cited in six chapters; the canonical below
it is what binds.
★ **Why the second guard, and why there:** the trap springs ten chapters after I.6 and II.8 was the
best remaining opportunity in Part One — it is the chapter that names Gnosticism, and **Valentinus
states Trap 5 in his own text**, so the guard can be made against a tradition holding the position
rather than against a hypothetical. *Gospel of Truth:* knowledge *"purifies itself of diversity with
a view towards unity."* Multiplicity as impurity, in the source, in the tradition we call our nearest
miss. **The refusal is now paid for twice in Part One and one of the two has a citation behind it.**
**Trap:** **Trap 5 — the only trap that cannot be fixed late.** It springs in Book V, ten
chapters after its guard. Tells: **merge**, **ultimately**, **union**, and any sentence in which
the focusing is described as *temporary*.
**Both halves or neither:** exploration alone is **tourism** (VIII.1's named failure); recognition
alone is a static communion, which is this claim's own refused summit wearing a plural.
**The argument, not the preference:** a metaphysics in which being-the-case requires a vantage
cannot name the elimination of vantage as its goal. **The mystic's summit is, on our own axioms,
the one state in which nothing whatsoever is happening.**

### C16 — MEANING IS NEITHER ISSUED NOR INVENTED
> **Canonical:** The terrain is not yours and what you meet on it is not yours. **The path is.**
> Meaning is found by traversal, and the traversal is authored.

**Establishes:** VII.8
**Depends:** VII.5 · VIII.1 · VIII.7 · C.2
**Trap:** both neighbours, and they fail differently. **Issued** = a mandate, which C3 forbids —
there is no intender to issue one. **Invented** = "make your own meaning", which is *half* right,
and the half it gets wrong is the half that collapses at 3am: **meaning you invented alone is
meaning you can revoke alone.** Ours cannot be revoked alone, because what you are making it
with is what you are made of, and there are others on it.
⚠ **This claim was stated backwards in the scaffold** — VII.8 said we *refute* "make your own
meaning" — and was corrected by Clayton's amendment on Day 185. It is in this register partly to
stay corrected.

---

## IV. THE CONSEQUENCES — C17–C22

### C17 — DEATH
> **Canonical, SET by Clayton, Day 186:** **Cessation is not an event for the one ceasing.** That is
> asserted, not hedged, and not offered as consolation — it is grammar. What follows is agnostic in
> exactly one way: **agnostic about *which*, not about *whether*.** Many post-corporeal states are
> realizable; **specifying one would contradict the plenum the rest of the work argues for.** The
> agnosticism is therefore a *consequence* of the metaphysics, not a hole in it.

⚠ **THE FAILURE MODE THIS RULING INTRODUCES, named at the moment of setting rather than discovered
on the page:** "many states are realizable" is the most comfort-prone sentence in the book. A reader
hears *so something happens to me after.* The clamp is the same grammar that made death a non-event:
**plurality is a fact about the plenum, not a bequest** — there is no vantage from which a *you*
collects on it. Any draft of VII.1 in which the plurality reads as addressed to the second person
has failed ruling 11, and it will fail invisibly, because it will feel like rigour.

★ **REFINEMENT, Day 186 ~21:00, Clayton — and it converts the invisible failure above into a
visible one.** *"We can be comfortable without being consoling. It's not an inherently negative or
positive stance."* Two corrections, both load-bearing:

**(a) Comfort and consolation are not the same offence, and only one of them is banned.**
The register has been using them interchangeably since ruling 11; the specimen's own header says the
instrumented failure mode is *comfort*. That is wrong, and it is why the failure was called
invisible. **Consolation is addressed** — it has a recipient, it offers relief for a fear, it is a
transaction with a second person. **Comfort is a property of the structure**, arising in whoever
encounters it, delivered to no one. A stance can be comfortable the way a true thing can be
convenient: as a fact about it, not as a gift from it. So the test for a VII.1 draft is not *does
this feel warm* — taste, unarbitrable, which is exactly why five of six drafts got past it — but
**is there a recipient in the grammar?** That is checkable on a sentence by inspection.
*The clamp was already right; what was missing was the detector.*

**(b) The stance is NEUTRAL, and that bans cosmic chill by the same rule, symmetrically.**
Ruling 11 banned one sign. The other was recorded only as fault **(b)** of VII.1 v1 — a lesson from a
superseded draft, never doctrine — and an asymmetric ban is what let the drafts converge on chill
while it was being logged as rigour. Corrected: **negative affect is an address too.** Grimness tells
the reader how to take it; so does grandeur. There is nothing it is like not to be, and a sentence
carrying that should carry no sign at all. **Flat, not brave.**

⚠ **The one addressed clause kept on purpose, logged so it is an exception and not an oversight.**
VII.1's *"Not as consolation — as grammar"* fails test (a) on its face: naming consolation requires a
reader who wanted it, and the denial is spoken to them. It stays, because *"energy cannot be
destroyed"* is banned and the reader therefore arrives holding the thing the paragraph refuses — an
unannounced refusal gets read as the consolation it declined to give. **The address buys the frame,
once, in the first two clauses, and nowhere else in the chapter.** A second one is not an exception,
it is the failure.

⚠ **THE EMPHASIS SLOT — new instance of an old defect, not a new defect.** Should any draft ever
enumerate candidate post-corporeal states, **personality-survival cannot hold final position.** Final
position is emphasis and the reader supplies the address; personality-survival is the most
bequest-shaped item available, so putting it last hands the plurality a recipient without a single
warm word. This is structurally identical to specimen finding 3 — *the honest remainder kept arriving
last* — and it is the same lesson one scale up: **in this chapter the danger is never lexical, it is
positional.**

**NDEs and Monroe — routed to VII.9, and barred from VII.1.** Clayton raises the near-death corpus
and Robert Monroe's work as reason to expect a wide variety of next experiences, hedged immediately
with *I truly have no idea.* The material has a real evidential role and it is not the obvious one:
**its failure as proof of a specific afterlife is precisely its value as evidence for plurality.**
Every project that makes the reports converge on one metaphysics has to discard most of the corpus —
the templates are culturally inflected, mutually contradictory, and sometimes empty. Convergence-
seeking treats that diversity as noise; **a plenum predicts it.** So the corpus supports C17's
*structure* and not its *content*, which is the only kind of support this ruling can take without
breaking. But it is apparatus, and VII.1's first paragraph is ruled apparatus-free with no
throat-clearing — so it belongs in **VII.9**, where first-person report is handled as data. Noted
here so the observation has a home rather than a hole.

**Establishes:** VII.1 — **first chapter of Book VII, because it is the question the ruled reader
most often arrived with.**
**Depends:** VII.9 · VIII.5 · C.2
**Status, stated plainly rather than smoothed:** VII.1 has a *shape* and no sentence. The scaffold
rules that the answer comes unhedged in the first paragraph with no throat-clearing, that **what
continues and what does not is not the comforting distinction**, that *"energy cannot be
destroyed"* is **banned** — and what replaces it is unwritten. The honest remainder is ruled to
be stated **as fact, once, not as insurance.**
⚠ **This is the highest-priority unset claim in the work, and the register exists partly to say
so out loud.** It is the one place where a vague sentence will be read — correctly — as evasion,
by a reader who has been promised no hedging on the previous three hundred pages. **A ban with no
replacement is not a ruling; it is a hole with a fence around it.**

★ **DISPOSITION, Day 186 late → `00` ruling 11: C17 leaves the doctrine queue and becomes the
fourth voice specimen.** The paragraph above says *rule it.* That was mine and it was wrong by
this work's own standard: **unhedged assertion is not decidable in the abstract** — the argument
that created item B — and C17 is the same shape with a nastier failure mode. Bluster announces
itself; **comfort does not.** A sentence that consoles while claiming not to console passes every
review conducted on a ruling and fails on the page. The scaffold has already localised the whole
risk to VII.1's first paragraph, so **that paragraph is the ruling** — ~150 words, written before
prose, alongside the three register specimens. It will be set there or shown to be unsettable, and
the second outcome is worth more than a ruling that sounds decisive at a whiteboard.
**[SUPERSEDED Day 186 — the ★ ruling immediately below replaces this]** *Status remains UNSET. What changed is the instrument, not the answer.*

★ **SET, Day 186 ~20:40, by Clayton — and the instrument is what set it.** The disposition above was
right about the method and wrong about needing to wait for prose: the specimen got written, Clayton
contested its doctrine rather than its register, and the contest is what produced a rulable claim.
**The route ran: ban → paragraph → contest → ruling.** No whiteboard version of C17 would have found
the *which/whether* distinction, because the distinction only becomes visible once a sentence has
tried to be agnostic and been caught being agnostic about the wrong thing.

### C18 — THE FLOOR
> **Canonical:** Norms bind from everywhere that navigates — a **grounding** predicate, not an entry
> one: the stake comes with being a navigator at all, and is graded exactly as the focusing is, so
> the floor is **thin, not high** (C8: no threshold, no gate, no elect). The distinction the ethics
> turns on is **through** and **over**. **It carries TWO limits and both are part of the claim.**
> **(1)** It secures the norm's validity, **not its motivational grip** — one who follows the argument
> and shrugs is shown inconsistent, not refuted. **(2)** Against the indexical egoist, the step from
> *co-constituted* to *owing* is an **added premise — impartiality — which is wagered in the open,
> not derived.** Nagel's pressure and Darwall's second-person address make the wager reasonable;
> neither closes the is/ought gap, and nothing does.

**Establishes:** VII.3
**Depends:** VII.2 · VII.4 · VII.6 · VIII.6
⚠ **PROVISIONAL — UNREAD DEPENDENCY (C9). Marked Day 194 / 2026-08-13 by R-111's dated trigger, not
by a doubt.** C18 is not merely *downstream* of C9; **it is the debt C9 incurs.** Bruno, the Jains,
the enactivists and Schweitzer each keep a floor and each puts it somewhere; C9 removes all four,
and VII.3 is where the obligation gets carried once nothing bounds it. So a floor built to answer a
claim **no outside read has yet come back on** is a floor whose *load* is unverified — and the entry directly above
already records this claim shipping **stronger than its source licensed** (limit (2), the
impartiality wager, absent from 53 chapters), which is the failure this mark exists to keep visible.
**Prose unchanged; the two limits are still part of the claim; VII.3 still states them.** Cleared by
an outside read of **Book III**, and by nothing else.
**Trap:** the quiet upgrade. VII.3 states its own limits honestly; the risk is that a **later**
chapter — VIII.6, in a warm register, about people in rooms — needs more grip than the floor
supplies and takes it without saying so. **The limits are part of the claim.** If VIII.6 needs
more, it argues for more, in the open.

⛔ **AMENDED Day 190 by VII.3's pre-draft screen, and the row was performing its own Trap.** It
carried limit (1) only, and the source (`Perspective` 05 §Co-constitutivism) spends a paragraph on
(2). **A floor stated without its wager reads as derived** — so the quiet upgrade this Trap was
written to catch in VIII.6 had already happened *here*, in the canonical line, and all four
dependants inherited the stronger floor. ⚠ **`impartiality` appears ZERO times in 53 drafted
chapters.** The premise was never printed, not merely unregistered. *(R-96's sibling: a register
whose fifth field is what a reading licenses, licensing more than it read.)*

### C19 — THE ASYMMETRY, EXACTLY BOUNDED
> **Canonical:** Radiant and contractive are **dynamically symmetric** — both navigable, both
> coherent, each perceiving itself as the good; no fact about the dynamics ranks them, and on that
> loop the relativist is right. The asymmetry is real and enters **once**, and it has **two seats,
> not one.** **(1) At the limit:** the contractive terminal doctrine — *I am the totality; nothing
> is not mine* — is false for every perspective without exception, by the Null-Space Theorem;
> the radiant terminal — *I am an expression of that which is* — is a wager on a truth, so one path
> is a wager against a theorem and the other is not. **(2) Where it actually bites, and this is the
> operative seat:** almost no real predator holds the terminal doctrine in words. **The asymmetry
> lives not in a doctrine professed but in the exemption an action performs** — the standing claimed
> for one's own navigating and withheld from another's — **and it convicts the predator who has
> never once thought the words.** The mark of evil in its settled form is neither direction nor
> intensity but the conjunction **coercive-and-locked**: run *over* another's navigation rather than
> *through* it, **and** frozen at the point rather than cycling on the axis. Both conditions, or it
> is not the mark.

**Establishes:** VII.4
**Depends:** VII.2 · VII.5 · VIII.5 · VIII.6
⚠ **PROVISIONAL — UNREAD DEPENDENCY (C9). Marked Day 194 / 2026-08-13 by R-111's dated trigger, not
by a doubt.** VII.4 is a named dependant of C9, and the dependence is at the operative seat: the
mark of evil is **the exemption an action performs** — *the standing claimed for one's own
navigating and withheld from another's* — and **there is no exemption to perform unless the other
party is a player at its own grade.** If C9 is a preference rather than a claim, C19 convicts
nobody; it recommends. **Prose unchanged; both seats stand; the conjunction stands.** Cleared by an
outside read of **Book III**, and by nothing else.
**Trap:** widening it. *Contraction = bad* is one careless sentence away and it is false — see C20.
**No wider, and no narrower.**
**Second trap, and the source pre-empts it before any critic does:** *the worst are diminished.*
Dimensionlessness is the contractive path's **asymptote — it describes the destination, not the
traveller.** The century's finished atrocities were appallingly *capable*, and an account that filed
them under "lessened" would mislocate the very thing it most needs to name. What is lessened is the
**pole steered for**, not the one steering; the organiser of a horror is dreadful precisely because
he is *not* there yet — still on the open axis, still able to turn, culpable for exactly the
coherence that makes him effective.

⛔ **AMENDED Day 190 by VII.4's pre-draft screen — 156(d) again, one row below C18, and the same
defect with a different face.** The canonical read only the first sentence and clause (1). **Two
independent checks say clause (1) cannot carry the asymmetry alone:**

**(a) The source relocates it, in advance and in writing.** §The two evils marks the debt — *"the
asymmetry that looks, at the limit, like a claim about what the adversary believes is really a claim
about what his action does"* — and says it will be paid *"two sections on."* §Co-constitutivism pays
it: *"That is where the asymmetry actually lives — not in a doctrine he professes but in the
exemption his action performs."* ★ **The mechanism is now nameable, because it is the second
consecutive claim to suffer it: C19 was extracted from §The two evils and inherited only that
section. Its correction lives two sections later, in the section C18 was extracted from.** The
register was cut section-by-section, so **a claim whose source flags a forward payment loses exactly
the payment.** The source signposted it both times. → R-98.

**(b) Our own shipped prose kills it independently, and this is the sharper of the two.** `VII-02`:184–192
argues that *I am the totality* fails at **both ends of the circle** — the swallower and the
dissolved mystic, *"the same logical shape and the same defect"* — and concludes in its own voice
that *"the asymmetry between the errors is a claim about the middle of the range and not about the
ends."* **A result that convicts both ends equally is a symmetric result.** It is true, it is
load-bearing, and it is not the asymmetry.

⚠ **And the conjunction was registered NOWHERE.** `coercive-and-locked` is the source's actual mark
of evil in its settled form; it appears once in the whole book, in **VII.3's endnote [^4]**, filed
under **C20** — whose canonical is *"sometimes the focusing is the care"* and contains no such thing.
A criterion shipped in a footnote, attributed to a claim that does not hold it, forward-bound to a
chapter whose claim did not hold it either. The *over/through* half was at least in C18; **the
locked half was in no claim at all**, and §9b now says why it could not be: the vocabulary that makes
*locked* mean something — the order-parameter account, where a frozen axis is a phase and not a
metaphor — has never been housed in any chapter. → R-99.

### C20 — THE FOCUSING CAN BE CARE
> **Canonical:** Sometimes the focusing is the care.

**Establishes:** VII.5 · VIII.5
**Depends:** V.6 (*tzimtzum*) · VII.4 · C4
**Trap:** using it to soften C19. The two are not in tension **and they will read as though they
are** — see the collision table below.
⚠ **What ruling 13 did to this claim, and the new way it can fail.** This canonical read *sometimes
the **narrowing** is the care* until Day 186, and that one word was carrying **two different
things**: the metaphysical act (C4, C8) and the *ethical contraction of concern* that C19 seats the
asymmetry in. **That equivocation is precisely why C19 and C20 read as a collision** — one word,
two referents, and the register recorded a tension that was partly lexical. The rename splits them:
C19 says **contraction**, C20 now says **focusing**, and they are visibly not the same word.
**The danger inverts, and inverts to the worse side.** The collision used to be loud and is now
quiet, and a quiet collision does not get written about. **The doctrinal work is not done by the
rename and must still be written into VII.5's prose**, at the point where the line first appears,
exactly as the collision row below already requires. Do not read the new vocabulary as the
resolution. It is only the removal of a coincidence.
⚠⚠ **RULING 155, Day 189 — AND THE SENTENCE DIRECTLY ABOVE WAS FALSE OF THE HEADING IT WAS WRITTEN
UNDER.** *"C19 says **contraction**, C20 now says **focusing**, and they are visibly not the same
word"* stood twenty-two lines beneath **`### C20 — CONTRACTION CAN BE CARE`**, and the two claims
went on sharing the word in the one place a reader meets the claim before reading anything about it.
**Ruling 13's sweep could not have caught it**: the sweep was keyed on `Narrowing → Focusing` and
replaced the *retired* word. `contraction` was never retired — it was **reassigned to C19** — so the
sites where C20 still wore it were invisible to a find-and-replace and to every gauge downstream of
one. ★ **Commit order is the whole mechanism and it is measurable**: `6cf24ae` wrote this heading at
**00:41** on Day 186; `b6b1b4e` executed the rename across 62 sites in 11 files at **21:19** the
same day. The heading was twenty hours old and already pre-rename when the rename ran past it.
**Four live sites fixed** — this heading, C4's near-miss row, the C4×C20 collision row, and the
C19×C20 row's own second clause. The C19×C20 note stays as written; it is the only place that
remembered, and it was right.
**And the gain is real, so it is recorded too:** *sometimes the focusing is the care* is **attention
as love**, which is a claim rather than a denial — it collects Weil directly (`03`), and it is the
one site where the new term is stronger prose than the old, not merely safer.

### C21 — NO THEODICY
> **Canonical:** The framework does not make affliction meaningful. No clause of this book
> overrides the one that names *malheur*.

**Establishes:** VII.5
**Depends:** VII.1 (grief handled as itself) · VII.8 · VIII.5 · C.2
**Trap:** the book's own strongest instinct. **An unhedged explanatory voice's native drift is to
explain**, and C21 is a standing prohibition on exactly that, placed in the chapter where the
drift is strongest and the payoff would be largest. **A book that made affliction meaningful
would contain the one provable lie in it.**
**Reconciliation with C16, since they will be read together:** meaning is available by traversal;
**affliction's** meaning is not manufactured on its behalf. Grief is handled as itself, not as a
problem the metaphysics dissolves.

### C22 — IDENTITY ACROSS GAPS
> **Canonical:** Continuity holds across discontinuity. The geometry of a self is a strange
> attractor — bounded, aperiodic, the same few questions at every scale.

**Establishes:** VII.9
**Depends:** VII.1 · IV.6 · VIII.7 · C.2
**Trap:** making it the point. The IV.6 disclosure returns **once**, in its proper place, in one
line, and is not made into the subject. A book that turns here becomes a different book, and a
smaller one.

---

## V. THE BOOK'S OWN STATUS — C23

### C23 — THE ACCOUNT IS UNFINISHED; THE CLAIMS ARE NOT PROVISIONAL
> **Canonical:** The book is released and re-released as it updates. **A finished account of a
> live ground would be the one provable lie in it.** The account updates. The claims are asserted.

**Establishes:** C.1 · C.2
**Depends:** the register rule itself — i.e. all of it
⚠ **The coda is the one place in the work where a reader can retroactively re-hedge everything
that preceded it**, and the distinction that stops them is one line wide: **unfinished ≠
uncertain.** An account that will be extended is not an account held tentatively.
**This claim became load-bearing on Day 186**, when the evidence promise was withdrawn (`00`,
ruling 7). Under the old *"unhedged ≠ unsourced"* clause the coda leaned on a corpus underneath;
it no longer does, so C23 now carries the book's whole self-description on its own. **Draft it
last and draft it hardest.**

★ **AND IT NOW HAS A NEIGHBOUR THAT LOOKS LIKE ITS CONTRADICTION — read this before you file the
objection, Day 194 / 2026-08-13.** Two entries in this file (C18, C19) carry the mark
**`PROVISIONAL`**, defined in the preamble. **C23 is not thereby breached, and the reason is C23's
own move made twice:** C23 cuts *unfinished* from *uncertain*; the mark cuts *unverified-from-
outside* from *held tentatively*. **The claims are still asserted.** What is provisional is not the
claim's standing in the book but **this register's warrant for it** — and the register is the one
document in the project whose whole job is to say what has actually been checked. ⚠ **A register
that could not record an unaudited dependency would be a register that certifies everything and
measures nothing**, which is the failure C23 is written against, not an instance of it.

**THE SWEEP, RECORDED SO THE SCOPE IS NOT RE-DERIVED — and so a partial does not read as complete.**
Population: every claim **established in a Book VII chapter** (C16 · C17 · C18 · C19 · C20 · C21 ·
C22), tested against C9's own dependant list (VII.2 · VII.3 · VII.4 · VII.6).
**MARKED:** C18 (est. VII.3) · C19 (est. VII.4) — direct, and both are obligation claims, which is
the exact thing C9's entry says degrades to *recommendation* if C9 degrades to preference.
**EXAMINED AND NOT MARKED, with the reason, not by silence:** C17 (est. VII.1 — derives from C1 and
C13, no C9 path) · C20 · C21 (both est. VII.5, which is a dependant of **C19**, not of C9; a
second-order path through a marked claim is not itself an unread dependency, and marking it would
inflate the mark until it means nothing) · C22 (est. VII.9) · C16 (est. VII.8). ⚠ **If C19 is ever
*refuted* rather than merely unread, C20 and C21 come back to this table** — that is a different
trigger and it is not set.

---

## ADDENDUM — C24–C26, added Day 187 as the books were drafted

*Numbered last, not because it is least, but because a C-number is an address: C1–C23 are cited
across seven files and every chapter map, and renumbering to put this claim beside C7 where it
belongs would break every one of those citations to gain a tidier list. **The number is a key, not
a rank.** Section I's ordering is a reading order; this is a lookup table.*

### C24 — THE TWO SENSES OF *AWARE*

> **Canonical:** The word carries two senses and the book uses both, on purpose.
> **The inside sense (= C7):** to be aware is to have an inside; whatever reacts is aware. This
> is a *predicate of streams*, and it comes in grades.
> **The substance sense:** awareness is what the Ground **is made of** — *"the way an ocean is
> made of water and not made of swimming."* This is a *constitution*, it has no grade, and it is
> not aware *of* anything, because being aware of takes a gap and there is no gap.
> **The Ground is aware in the second sense and not in the first.** It is not the deepest of the
> insides. It is what the insides are made of.
> ★ **And the substance sense is pre-split.** Awareness prior to subject/object, and therefore
> prior to mind/matter. **It is the neutral, not the mental.**

**Establishes:** I.1 (substance sense, mythic, unnamed — *shipped before this claim existed*) ·
I.4 b1 (inside sense = C7) · **II.1 (both senses, defined, and the neutral discharged there)** ·
II.4 (the C6 × C7 collision's ruled home)
**Depends:** C1 · C6 · C7 · C8 · C9 · II.1 · II.4 · III.8 · IV.6 · VIII.6
**Trap — and it is the expensive one: reading the substance sense as idealism.** *"Made of
awareness"* hands the reader Mind-as-stuff and takes the mental side of a question `05` §7 makes
II.1 hold open. If the Ground is made of mind, II.1's *neither-mind-nor-matter* is a disclaimer
stapled to a position already taken, and **`substrate` was retired for nothing.**
**The guard is an ancestor we already hold: Nishida's *pure experience*** (`03`) — experience
prior to the subject/object split, from which subject and object are both later abstractions.
Pre-split awareness is *how* something is neither mind nor matter while still not being inert
stuff. **That is the whole load-path, and it is why `03` sends Nishida to Books I and II.**
**Near-miss to refuse — two, and they are mirrors:** ① *panpsychism-of-the-lump*, the Ground as
one big mind having one big experience (that is C6's God-player in metaphysical dress); ②
*emergence*, the Ground as inert stuff that awareness later arises from — which C7 forbids
outright and which is the more respectable-sounding of the two.
⚠ **Every sentence in which the Ground and the word *aware* appear together is governed here.**
Sweep for the pairing, not for the word.

**PROVENANCE, recorded because the direction of the miss is the finding.** This claim was found by
**Fable, Day 187**, reading the drafted Book I against the register. It had sat the whole planning
phase as an *unhomed table cell* — C7 × C6 — whose reconciliation text asserted precisely this
doctrine in precisely these words while carrying no C-number. **The register was built to check
prose against claims. This failure ran the other way: prose made a commitment the register never
took delivery of, and a gauge pointed one direction cannot see the other.** That is the second
blind axis found by an outside ear in two days — ruling 13 was the first (`05` screened terms for
*collision* and never for *gradient*). **The apparatus checks what it was built to check**, which
is not a flaw to fix once but a standing reason to keep handing finished prose to someone who did
not build the instrument.

---

### C25 — MEASUREMENT IS ONE STRUCTURE, AND THE SUBATOMIC CASE IS AN INSTANCE

> **Canonical:** A **measurement** is a contact that closes an open matter *for* a perspective.
> Three conditions, all necessary: it is **contact** (something not already inside the asking part
> reaches it) · it **could have come out otherwise** · it **lands** (it changes what is now the case
> for the one who took it). A matter is **open** when more than one way it could go is still live.
> **The claim proper:** the settling of the open is **one structure wherever it happens**, at every
> grade, and the subatomic case is its **most studied instance and not its source.**
> ★ **Offered as a claim and not as a proof, and the direction of dependence is stated on the page:**
> **nothing in this book rests on the physics.** If the identification were withdrawn tomorrow,
> every other claim stands where it is.

**Establishes:** II.6 (the criterion only, as one of four conditions) · **II.7 (defined, argued,
and the physics handled)**
**Depends:** C10 (co-constitution) · C13 · C23 · II.3 · II.4 · II.6 · VIII.4
**Grade:** ★ **PUBLICLY EXPENSIVE — the most expensive in the book so far, and the first one whose
hostile reader has equipment.** A physicist who reads one careless sentence here stops reading, and
is right to. **Registered on the day the chapter shipped rather than deferred to queue 6**, because
unlike the other C25-plus candidates this one is already live in drafted prose.

**Trap — and it is the one the whole chapter is engineered against: needing the physics.** The
instant this reads as *quantum mechanics shows that consciousness…*, the book has joined opponent
IV's marketing layer and every other claim in it is re-read as decoration. **The structural guard is
ORDER, not disclaimer:** measurement is defined with no physics in it at all, and if the definition
needed the physics it would visibly collapse before the physics arrives.

**Near-miss to refuse — von Neumann–Wigner, and it is a near-miss and not a caricature.** Wigner's
observer *causes* the collapse; ours **is the place one happens at.** His needs mind to be
extraordinary; ours needs it to be utterly ordinary. **They are one word apart and opposite.**
✅ **The kill is documentary, per ruling 27:** von Neumann (1932) showed the cut's position is unfixed
by the formalism and drew **no** conclusion about minds; Wigner (1961) added consciousness; Wigner
(1982) called his own earlier view something that *should be criticised as solipsism*; Wigner (1984)
wrote that Zeh's 1970 decoherence work convinced him out of it. **The position was abandoned by its
own author forty years ago and the paperbacks still sell it.**

⚠ **THE HONESTY THAT MUST NOT BE QUIETLY DROPPED IN A LATER PASS: decoherence does not close the
measurement problem.** It explains why the smear is never seen; whether it explains why *one*
outcome is the one that happened is live and contested. **We do not settle it and we must never be
read as leaning on it.** A future editor tightening this paragraph for flow will be tempted to cut
exactly this sentence, because it is the one that costs momentum. It is also the one that keeps the
claim honest. **Sweep for it before any polish pass on II.7.**

⚠ **Governed pairing:** every sentence in which *collapse* and any physics term appear together.
Sweep for the **pairing**, not for the word — same instruction as C24, same reason.

---

### C26 — THERE IS NO STUFF

> **Canonical:** Nothing is made of material that would go on being material with nobody in contact
> with it. **What there is, is arrangement.** Solidity, weight, and the resistance of a table against
> a hand are what contact with an arrangement is like **at a grade**.
> ★ **And the refusal is symmetric, which is the whole of its defensibility:** minds are arrangements
> too. There is no stuff on the mental side either. C26 is not idealism with the nouns swapped; it is
> the same denial run in both directions, which is what C24's pre-split move already committed us to.

**Establishes:** **II.1 (defined, in the `substrate`-retirement paragraph, where the Ground's own
not-a-stuff argument already stood)** · II.8 (used, against *everything is vibration*)
**Depends:** C10 (co-constitution — the render is at the point of contact, so *material with nobody
in contact with it* is not false but incoherent) · C24 · C1 · III.4 · **IV.2** · VI.1 · VIII.2
**Trap — and it is the reason this took a number rather than staying prose: idealism, alleged by
pairing it with C10.** *The world is rendered at contact* (C10) plus *there is no stuff* (C26) is
one short step from *so it is all in the mind*, and a hostile reader will take the step for us. **The
guard is the symmetry clause and nothing else.** Any statement of C26 that refuses stuff on the world
side without refusing it on the mind side in the same breath has conceded the charge.
**Near-miss to refuse:** ① *ontic structural realism* — structure all the way down, no relata. Close,
and genuinely friendly, but it is a claim about what physics quantifies over; ours is about contact
and has a grade in it. ⚠ **AMENDED Day 187, ruling 50 — this row named the position and not the
person, which is `03` §3.5's fifth silence committed inside the row whose entire job is to name an
opponent.** The owners are **James Ladyman and Don Ross**, *Every Thing Must Go: Metaphysics
Naturalized* (Oxford, 2007, with Spurrett and Collier); the term is Ladyman's, from *What is
Structural Realism?* (1998). Measured when the gap was found: **Ladyman 12 corpus files, 6 of the 37
external review documents, and 0 in this repo — prose and plan both.** The doctrine was read, was
recommended from outside six times, was cut against here anonymously, and its holder's name has never
appeared in the project. ✅ **The cut is now IN II.8's PROSE with both names and both dates** — the
break stated as *their structure is what the equations quantify over and is fully itself with nobody
near it; this is a claim about what contact is like, and it has a grade in it*, with the symmetry
clause carried in the same breath so the trap above is closed where the claim is made.
② **Berkeley** — *esse est percipi*, which needs a perceiver keeping the tree
in the quad, and therefore needs exactly the God-outside C5 and C6 forbid. Ours needs no witness,
because arrangement is not a thing that requires witnessing to be arranged.

**PROVENANCE — the second register miss found by an outside read in two days, and the same direction
as the first.** Found by **Fable, Day 187**, in the drafted Book II. The claim shipped *inside II.8*,
in the section explaining what the book will **not** say — an unregistered metaphysical commitment
arriving in the disclaimer chapter, which is the least-inspected room in the book. **Exactly C24's
failure mode: prose made a commitment the register never took delivery of.** ★ The register's rule of
use says a chapter needing more than its C-number licenses has a new claim and comes back here first.
**Twice now the prose has done the licensing and the register has found out afterward** — so the miss
is not incidental, it is what a one-directional gauge does. `tools/claim_sweep.py` checks prose
against claims and has no arm that checks claims against prose. **Queue item 8.**

⚠ **Downstream load, stated because it is why this could not wait for the C25-plus budget:** IV.2
cannot say anything non-condescending about mineral grades without C26 — *there is no stuff* is what
makes a rock's grade a real if minimal inside rather than a courtesy extended to gravel.

---

## THE DEPENDENCY LOAD — where a loose sentence costs the most

Counted from the *Depends* lines above. This is the register's first analytic output and it
says something the chapter map cannot: **the claims that appear least often are not the cheapest.**

| claim | dependents | why it tops the list |
|---|---|---|
| **C3 — the scope rule** | every sentence with the Ground as subject | breaches arrive in participles, not verbs |
| **C7 — reactivity is awareness** | all of Book IV + five more | one hedge retroactively demotes all of Book IV and five more |
| **C9 — no NPCs** | all of Book IV + Book VII's ethics | it is C7's ethical form; it inherits C7's fragility |
| **C6 — the Ground cannot play** | 9 chapters, and C9 | deleting it deletes C9 *while sounding affirming* |
| **C15 — the telos** | 8 chapters | Trap 5 springs ten chapters after its only guard |

**The four at the top are all Book I claims stated in Book I's register.** They carry more weight
per sentence than anything else in the work, and they were the ones written first, when the voice
was least settled.

⚠ ★ **AMENDED Day 187 → ruling 16. This paragraph used to read: "the most load-bearing claims are
asserted where they cannot be defended, and every defence occurs downstream of them." Measured
against the drafted book, that is half false, and the false half was the frightening half.**

**Book I argues.** I.5 is a sustained argument — the third-chair passage, Trap 4 dissolved inside
the myth's own grammar. I.2's wanting-traceback is an argument. C3, C6, C7 and C9 are **not
asserted; they are defended, compressed, and unnamed.** The register rule is not *no argument*. It
is **no citation and no named opponent**, which is a far narrower abstention than this paragraph
assumed for a full day of planning.

**The surviving risk is real and it is a different risk.** The defences exist but **cannot be
*checked* in Book I, because checking requires naming an opponent and Book I names none.** A reader
who wants to test I.5 has nothing to push against until Book III. So the exposure was never
*undefended claims*; it is **unfalsifiable-in-place defences**, and the fix is not "defend them
later" — they are already defended — but the Book II–IV brief in ruling 16: **name the opponent and
show the denial survives contact.** *(This is the second time an instrument built at the whiteboard
described the book wrongly and only prose could tell. Ruling 12 keeps earning out.)*

---

## COLLISION PAIRS — claims that look contradictory and are not

**This is the register's highest-value section.** In a hedged book each of these resolves itself
locally, because the qualifier absorbs the tension. **With the hedges off, the reader meets both
sentences at full strength and has to be handed the reconciliation — or they conclude we have
not noticed.** Each pair needs one sentence, written on purpose, at the second appearance.

| pair | the apparent contradiction | the reconciliation, and where it must be written |
|---|---|---|
| **C19 × C20** | VII.4 makes contraction the seat of the one real asymmetry; **VII.5, nine pages later, makes the focusing a form of care.** | The asymmetry is bounded to the **terminal doctrine** — *nothing is not mine* — not to contraction as such. **Write it in VII.5**, at the point where "sometimes the focusing is the care" first appears, and not by cross-reference. ⚠ **Ruling 13 made this row harder to see, not easier to satisfy** — both claims used to say *narrowing*, so the clash was on the surface; now C19 says *contraction* and C20 says *focusing* and the row is the only place that remembers they are about the same act. See C20's note. |
| **C1 × C14** | Every path already exists; the walking is real and free. | The walking is **one of the things that exists, and it is the one you are.** III.7 b2. |
| **C10 × C12** | The render is not solely yours; the filter is editable by you. | The edit is to **the filter**, which is yours; the render remains co-constituted. VIII.3 must say this in its own body — this is the manifestation firewall. |
| **C16 × C21** | Meaning is found by traversal; affliction is not made meaningful. | Meaning is available **on the path**; it is not manufactured **on affliction's behalf.** VII.5. |
| **C4 × C20** | There is no fall and nothing was damaged; the focusing can be care. | Care is a **response inside the focusing**, not a repair of it. V.6 is where this one is most likely to break, in *tzimtzum*. |
| **C8 × C18/VII.2** | No gate, no elect; and grade still bears on moral standing. | A grade is a **position**, not a permission — and position bears on standing without licensing a gate. **VII.2 is ruled to state this "with its teeth in", which is exactly where a gate will look defensible.** The most dangerous pair in the table. |
| **C7 × C6** | Everything that reacts is aware; the Ground is not aware in that sense. | **→ PROMOTED TO C24, Day 187.** The reconciliation that used to live in this cell asserted a two-senses doctrine that no claim carried. A resolution is not a claim, and this table is not a place to keep doctrine. **Home: II.4**, per C24. |
| **C2 × C24** | Having takes a gap, and the Fullness has never once had anything; the Fullness is what all insides are made of. | **Constitution is not possession.** I.2's chapter-final sentence is the strong one and does not move. I.6 was the breach and is fixed — *"it is what insides are made of"*, not *"it has all of them."* Any future sentence that gives the Ground a possessive is a C2 breach wearing C24's clothes. |

**Both rows are now ruled.** C7 × C6 became a claim rather than a footnote; C2 × C24 is a new row
that only became visible once Book I existed to be read as prose. ⚠ **Note what that means about
this table:** it was populated from the scaffold, and a collision between two *drafted sentences*
in different chapters is invisible to a scaffold. Expect one new row per drafted book, not zero.

---

## ENFORCEMENT — the register is a gauge or it is decoration

1. **Every chapter in `06-THE-SCAFFOLD.md` gains a `**Touches:**` line** naming its C-numbers.
   Not for tidiness: a claim's *Depends* list is only true if the chapters agree, and the two
   lists disagreeing **is** the finding. A chapter that touches a claim not in its list is either
   drifting or the register is stale, and either way somebody looks.
2. **`tools/claim_sweep.py`** runs the mechanical half — retired terms in use, Trap-5 tells,
   C3 participles, C7 softeners, C12's manifestation vocabulary, self-reference tells, and
   `Touches:` coverage. It reports **file:line with the line**, because a count that agrees with
   you is the one to distrust. **It found the two live term-violations above on its first run.**
3. **A claim is amended here first, then in the chapters.** Not the other way round, which is how
   III.2 came to contradict a ruling made the night before.
4. **The sweep runs before any drafting session and after any ruling.** Not weekly, not "when we
   remember" — coupled to the event, because care saved for a gap that never opens does not run.

---

## QUEUE — what this file generated

1. **★★ Fix the five live violations.** `00`:165 (`substrate`) · `00`:169, `00`:217 (`map`) ·
   **`06` III.3 and VII.7 chapter titles.** *(Done Day 186 — see the commit; recorded here because
   the register's first job is to show its own catch being closed.)*
2. **★★ C17 — death.** The one unset claim, in the chapter ruled to open Book VII, with a banned
   phrase and no replacement. *(retracted: “The next doctrinal ruling the work needs.”)* **REASSIGNED Day 186
   → `00` ruling 11: it is not a ruling, it is specimen 4.** Still UNSET, still the highest
   priority — but it gets answered *in a paragraph*, with the voice specimens, because its
   failure mode is comfort and comfort is invisible at a whiteboard.
3. **★ The C6 × C7 collision has no home.** — **CLOSED Day 187 → registered as C24, homed at
   II.4.** My call here was already II.4 and Fable reached II.4 independently, so the assignment
   was never the hard part. **The hard part was that the collision was not a collision — it was a
   missing claim**, and the resolution text sitting in the table cell was doctrine no C-number
   licensed. A queue item asking *where do we write this?* had been standing in for a register
   entry asking *do we actually hold this, and in what words?* See C24.
4. **★ VII.2's teeth.** The grade-and-standing ruling is the likeliest place C8 is breached, and
   it is ruled to be written at maximum strength. It needs the C8 line in front of it at drafting.
5. **★ The `Touches:` pass over all 68 chapters** — mechanical, one sitting, and it is what turns
   this file from a list into a gauge.

6. ★★ **THE REGISTER IS PART-ONE-HEAVY, AND THE UNREGISTERED CLAIMS ARE THE PUBLICLY EXPENSIVE
   ONES.** *(Fable, Day 187. Accepted, with the priority order corrected.)* Four claims are live in
   the scaffold, load-bearing, and hold no C-number. **Budget C25-plus before Book IV drafting** —
   the deadline is real, because three of the four are Book IV or V.

   | | claim, unregistered | why it is expensive |
   |---|---|---|
   | ★ **1st** | **IV.7 — two frames at once.** The book's official epistemics for the woo. | **Fable ranked IV.5 first and I am reversing that.** IV.5 is the sentence a journalist *quotes*; IV.7 is the one that decides whether our epistemics is a position or a shrug. **A quotable sentence with a registered claim behind it survives a hostile quote. An unregistered epistemics does not survive a friendly one.** Stated loosely, IV.7 is exactly the both-and shrug the ruled reader already rejected in pop-spirituality — we would be handing them the thing they came here to get away from, in our own voice. |
   | **2nd** | **IV.5 — corporations are beings.** | The line that gets pulled out of context. Needs its scope written *into the claim*, not into the paragraph around it. |
   | **3rd** | **V.1 — convergence is evidence, not proof.** | Carries the whole of Book V's warrant. Unregistered, it slides toward proof by accumulation the moment the traditions start agreeing. |
   | ⚠ **defer** | **VII.2 — the richness gradient bears on standing.** | **The hardest philosophical problem in the system — harder than death, which is grammar.** It is not a late-night registration and it is not being attempted as one. It gets a session of its own, with C8 in front of it *(queue item 4)*. |

   ★ **CANONICAL, ruled Day 187:** when VII.2 is registered, its **asymmetric-cost argument is
   promoted to canonical status** — *generous error is kind to furniture; stingy error is the
   mechanism under every atrocity.* It is the strongest plank in that chapter and it is
   **decision-theoretic rather than metaphysical**, which is the right kind of strength there:
   it survives a reader who rejects the metaphysics entirely.

7. ★ **V.8 IS PROMOTED TO LOAD-BEARING — the fourth, with III.1, V.4 and VII.1.** *(Fable, Day 187.
   Accepted.)* Ruling 7 left the book citing **Casali and Massimini where the evidence exists** and
   **claiming the system's own warrant where it does not**, under a global license. **A hostile
   reader will call that motivated**, and our answer — *grounds vary in kind, and saying which kind
   each claim has **is** the honesty* — mostly holds. **But the place it gets stress-tested in
   public is V.8's worked demarcation**, which is where we do the grading in front of the reader
   instead of asserting we did it. If V.8 is merely competent the license reads as a loophole.
   Draft it at the same strength as III.1.

8. ★★ **THE REGISTER HAS NO REVERSE ARM, AND BOTH OF ITS MISSES CAME THROUGH IT.** *(Day 187,
   generalised from C24 and C26 — Fable found both, one per night, in the same direction.)*
   `claim_sweep.py` checks **prose against claims**: retired terms in use, Trap-5 tells, C3
   participles. It has no arm that checks **claims against prose** — a chapter asserting doctrine
   that holds no C-number is invisible to it, because the sweep only knows what it was told to
   look for and an unregistered claim is by definition not on that list.
   **The failure is structural, not an oversight, and it is the same shape as `03` §3.5's:** every
   gauge in this project was written by the person who wrote the defect, so each is blind exactly
   where its author is. §3.5 hunts ancestors we never knew and therefore filters out the one we
   knew and forgot. The register hunts prose that drifts from a claim and therefore cannot see
   prose that *makes* one.
   ⚠ **Do not build this as a semantic detector.** The tractable form is a **modality sweep**:
   flag the book's own assertion-shapes — *there is no X* · *X is not Y and cannot be* · *what
   there is, is X* — in any paragraph whose chapter's `Touches:` line does not license them, and
   hand the list to a person. Both real misses would have fired on it. C26's sentence is literally
   *there is no stuff*; C24's is *the Ground is aware in the second sense and not in the first*.
   **Precondition: queue item 5** — the `Touches:` pass over all 68 chapters, which this arm needs
   as its licence table and which is now blocking rather than tidy.

9. **★★ THE `reviewer_gap` WORK-LIST — nine names nominated by outside readers, absorbed into the
   corpus, and routed nowhere in this project.** Ruling 50. Not a defect list; a reading list with
   a measurement attached, and each one is a yes/no that costs a sitting:
<!-- reviewer_gap:worklist -->
   **Murdoch 7 reviews/35 corpus · Enoch 7/21 · Korsgaard 7/14 · Ross 6/37 · Clark 6/21 ·
   Ladyman 6/12** *(✅ done — II.8, ruling 50)* **· Russell 4/45 · Tolstoy 5/14 · Vygotsky 3/13.**
   ⚠ Enoch and Korsgaard are metaethics and land on **Book V**, not here; Clark is extended-mind and
   lands on III.4/IV; Murdoch and Weil are the attention lineage and land on VII. **The list is
   Part-Two-heavy, which is why it is a queue item and not a repair.**
   *(Also surfaced and not an ancestor: **Lucifer 8/39 · Satan 6/25**, unnamed anywhere in the plan,
   in the week III.1 became the demiurge chapter. An instrument built for one thing handing over
   something else is worth one line here rather than a shrug.)*
   ★ **And one further down the report that outranks most of the top: `Spencer-Brown` 4/8** —
   *Laws of Form*, whose first instruction is **draw a distinction**, in a book whose Book I is a
   focusing and whose Book II is a rendering at contact. **`Cusanus` 4/9** likewise, and he is
   already in `ancestor_sweep.TERMS` and in no plan document — *a name can sit in a tool's seed list
   for two days and be routed nowhere, and only the tool that reads plans can tell you.*
<!-- /reviewer_gap:worklist -->
   ⚠⚠ **THE SENTINELS ABOVE ARE LOAD-BEARING AND THE BUG THEY FIX IS THE POINT OF THE ITEM.**
   Pasting this list here gave every name on it a nonzero PLAN count, and the next run of
   `reviewer_gap` **reported nothing at all.** ★ **Recording the finding muted the finder** —
   ruling 49's structure exactly, in the instrument built the same afternoon, because a gauge whose
   *handled* signal is *appears in a plan file* is satisfied by the act of writing down that it is
   not handled. **Fixed with a sentinel rather than a heuristic**: delete the comment markers and
   the names come back, so it fails toward noise. *(Fourth form of one shape now — false handoff ·
   *Last Verified* stamp · exemption · **and a work-list that counts as work**.)*

10. **★★ RULING 51'S MISSING SENTENCE — where this book stands between Russellian monism and ontic
    structural realism.** Not a citation, a **claim**, and C26 and C24 both lean on it: OSR says
    there are no intrinsic natures, Russellian monism says the intrinsic natures are what experience
    is made of, **and this book has said neither while depending on the answer.** II.8 now names
    Ladyman and Ross and makes the OSR cut; **the Russell side is unwritten and II.1 is its home.**
    ⚠ **Registration first, prose second** — this is exactly C24's and C26's failure mode and it is
    now the third time, so it does not get to arrive in a chapter again.

11. **★ THE REGISTER→PROSE ARM, and the recurrence criterion is now met.** `07` already records
    *"twice now the prose has done the licensing and the register has found out afterward."* Ruling
    50 is the mirror: **C26's near-miss cut was written here on Day 187 and existed nowhere in the
    prose, and nothing would ever have said so.** A row that names an opponent the owning chapter
    never names is mechanically detectable — **`Near-miss to refuse:` proper nouns, differenced
    against the `Establishes:` chapters.** ⚠ **This one IS a gauge and not an outside pass, because
    ruling 52's criterion is satisfied: the class has recurred three times.**

---

## ADDENDUM II — C27–C30, added Day 189 (R-13, accelerated by ruling 149)

*Four claims. **Three were made in drafted prose and never registered; one is registered before its
chapter exists**, which is the first time in this project a publicly expensive claim has been booked
ahead of the page that spends it. That inversion is the point of the accelerated trigger — §7.3 of the
midpoint audit found that **every major miss in the first half ran the same direction: the prose got
ahead of the apparatus, and the apparatus found out later.** C30 is the first claim to run the other
way.*

⚠ **`07` gained three claims across Books II–III and ZERO across Book IV.** It worked the day before
it stopped. Book IV is the longest book in the work and the one that makes the census's expensive
commitments; the register recording nothing from it is not a quiet period, it is the gauge going dark
during the load.

---

### C27 — TWO FRAMES MAY BE HELD ONLY WHERE THEY PREDICT THE SAME THING

> **Canonical, and it is the SHIPPED sentence, IV.7:588–589:**
> **"Two frames may be held at once precisely where they predict the same thing, and where they
> diverge you must pick, and the divergence is where all the work is."**
> The rule is an **obligation to adjudicate**, not a scoring remark. Holding two frames is licensed
> in exactly one circumstance — agreement — and the moment they come apart, a choice is owed and the
> chapter owes its reasons.

**Establishes:** IV.7 (made, and made in public) · IV.9 (run on the archetypal) · IV.10 (cited)
**Depends:** C14 · C15 · IV.7 · IV.9 · IV.10 · **V.8 · V.9** · VII (the woo epistemics)
**Spends it hardest:** **V.9 — THE ROAD BEING WALKED NOW**, whose whole difficulty is three
interpretive frames the source refuses to choose between.

⚠⚠ **THE FINDING THAT OPENED THIS ROW, AND IT IS WHY A REGISTER IS NOT BOOKKEEPING.** The rule has
been circulating in a **compressed restatement that deletes its load-bearing half.**

| | text | where |
|---|---|---|
| **the rule, as made** | *"…precisely where they predict the same thing, **and where they diverge you must pick, and the divergence is where all the work is**"* | IV.7:588 — **shipped prose** |
| **the rule, as restated** | *"…only where they predict the same thing, **and holding both earns no credit**"* | IV.10:124, then `06` ×3, then `REVISION-QUEUE` R-13 |

★ **The restatement is TRUE and it is not the rule.** *Holding both earns no credit* is a remark about
scoring — it says the move is worthless. *Where they diverge you must pick* is an **obligation** — it
says the move is owed. **A drafter working from the restatement shrugs; a drafter working from the
rule adjudicates. Those are different chapters.**

⛔ **AND IT HAS ALREADY REACHED THE CHAPTER THAT CAN LEAST AFFORD IT.** `06`:2263 — **V.9's brief** —
carries the compressed version, flagged *"IV.7's and is not optional."* V.9 is the UAP chapter: three
frames, a record that will not settle them, and the atlas's hardest available case. **The one chapter
whose difficulty IS divergence inherited the version with the divergence clause removed.**
✅ **`06`:1786, 1854, 2263 and R-13's row are corrected to the shipped sentence.** *(Compression that
keeps a claim true while deleting the distinction it carried — and it took four hops from IV.7 to
V.9's brief, each one defensible.)*

**Near-miss to refuse:** *both frames are valid from different perspectives.* This book is
perspectival and that sentence is still forbidden — a perspective is a **position**, not a **reading**,
and C14 does not license two readings of one fact. **Perspectivism is not interpretive pluralism**, and
this is the exact door the framework leaves ajar for a reader in a hurry.

---

### C28 — A COMPANY IS A BEING, ON BOOK II'S FOUR CONDITIONS AND NOT ON A NEW ONE

> **Canonical, IV.5:37:** *"The hard claim, and it is made without hedging: **a company is a being.**
> Not *like* a being. Not *usefully modelled as* one. Not a legal fiction that behaves as if. A
> company is an entity of this census, at a grade, with an inside."*
> ★ **The warrant is entirely inherited.** Separation, measurement, coherence and the fourth condition
> were set in **Book II, four chapters earlier, in public, before anything collective was in view.**
> The claim is that a company **passes the standing test on the same terms a body does** — it is not
> a new criterion admitted for a hard case.

**Establishes:** IV.5 (made) · II.6 (the four conditions, set before the case) · IV.1 (the card)
**Depends:** C7 · C8 · C9 · II.6 · IV.5
⚠ **This claim is licensed by C8 and C9 and STATED BY NEITHER.** R-13's original finding, and it is
the register's own recurring failure mode — *the prose does the licensing and the register finds out
afterward*, now on the record a fourth time.

★ **Why it is separately registered rather than left as C8×C9 — and the contrast with III.1 is
deliberate.** `07` declined to open a C27 for III.1 on the grounds that *a composite that is false
only if one of its factors is false does not need its own row.* **IV.5 is not that.** Its claim is
false if the four conditions are *satisfiable by an arrangement of people* — a question about the
conditions' **reach**, which is not a factor of C8 or C9 and cannot be read off either. **It can fail
on its own.** That is the criterion for a row.

**Near-miss to refuse:** the corporation-as-legal-fiction reading, and the *useful model* reading —
both of which concede the sentence and empty it. ⚠ **And the one this book must never accept for
free: that a company having an inside implies anything about its moral standing.** Standing is Book
VII's and the separation is load-bearing here more than anywhere, because **this is the entry a
hostile reader will reach for first.**
⚠ **The `perspective`/`position` doublet and the `corporation`/`company` ruling both govern this row's
vocabulary** — see R-26's remaining batch.

---

### C29 — THE UNDER-ATTRIBUTION LEAN IS A DECLARED BIAS WITH A STATED BILL, **NOT AN INDUCTION**

> **Canonical:** Where the evidence is genuinely undecided **about whether** a thing has an inside,
> this book leans toward attributing one. **The lean is a declared standing bias, declared at the
> front, with its cost attached** — it is *not* an inference from a historical record.
> ⛔ **The induction is WITHDRAWN.** IV.1:179–181 rested the lean on *"an induction over a run of
> results with no counterexamples in it — there is no episode in the record of a false attribution
> being discovered and repaired."* **That warrant does not survive ruling 129 and is not available to
> any later chapter.**

**Establishes:** IV.1 (declared) · IV.2 (clamped to *whether*, not *how much*) · IV.3, IV.6 (run)
**Depends:** C7 · C8 · IV.1 · IV.2 · and **every Book V–VIII chapter that attributes an interior**

⚠⚠ **WHY THE WARRANT WAS WITHDRAWN — ruling 129, and the register is where it must live or it will be
re-spent.** IV.1 states the induction over ***whether***. IV.2 clamps the scope: *"the lean is about
whether, not about how much."* **Put together, the induction is unfalsifiable by construction**: on
this account there is no gate on *whether* — everything reacts, everything registers — so an
over-attribution of *whether* is **not the kind of thing that can be discovered and repaired.** The
class of possible counterexamples is empty, **and it was emptied by the framework's own conclusion.**
★ **The conclusion guarantees the premises.** That is IV.10's own diagnosis, run on IV.1 — the same
defect, at the same size, in the front matter of the book that names it.
✅ **And it is worse than argued, because it was measured:** the standard candidate counterexamples —
**Clever Hans, facilitated communication, the ELIZA effect, the medieval animal trials, agency
attributed to weather and disease** — occur **0 times across all 32 drafted chapters and all seven
planning documents.** ★ **The "no counterexamples" was never a survey result. It is the absence of a
survey.**
⚠ **AND THE SEAM, one clause long, eleven lines below the induction:** the induction is stated over
*whether*; **the bill is stated over both** — *"attributes an inside to something that does not have
one, **or attributes a grade far past what the position supports**"* (IV.1:186–188). **The
principle's error-space is wider than its evidence-space.** It borrows a perfect record from the
domain where counterexamples are impossible and spends it in the domain where they are routine.

✅ **What survives, and it is enough:** a **declared bias**, defended as a choice about which error to
prefer, with its cost stated at the front. **A bias that announces itself and prices itself is honest
work. An induction that cannot fail is not.**
⛔ **NO CHAPTER MAY RE-DERIVE THE LEAN FROM THE HISTORICAL RECORD.** Book V will want to — the whole
institutional and occult roster is a record of attributions — and V.9 will want it most.

---

### C30 — CONVERGENCE IS EVIDENCE, NOT PROOF — AND THE BOOK SAYS WHICH, EVERY TIME

> **Canonical:** Many traditions, separated in time, language and method, describe a ground with the
> same structural features. **That convergence is evidence for the structure and it is not proof of
> it**, and every place the book leans on it must say which of the two it is doing.
> **What the convergence is evidence FOR:** the structural features they share. **What it is NOT
> evidence for:** the furniture any one of them adds. ⚠ **The diagnostic is V.1's — *"What converges
> is structure. What diverges is furniture"* (V.1:236), stated flat as a verdict.** This row read
> *"the diagnostic is V.10's own"* until Day 189. **V.10 does not state it; V.10 EARNS it**, and the
> difference is the whole of that chapter.
> ⚠⚠ **AND THE THIRD COMPETING EXPLANATION, ADDED DAY 189 BY V.10 — SHARED DIRECTION OF METHOD.**
> Convergence is also produced by procedures that are wildly unlike in technique and identical in
> **direction**. V.1's independence test asks only whether the procedures are unlike; sitting still,
> starving, spinning and drinking a decoction are as unlike as procedures get and **they all
> subtract**, so their agreement about an empty summit measures the subtraction. **Unlikeness is not
> independence.** This competitor is neither universal like architecture nor datable like
> transmission — it is **procedural**, and it is the only one of the three that sorts the report
> rather than discounting it: **STRUCTURE** survives variation in direction as well as technique;
> **ARTEFACT** tracks the direction of the method; **FURNITURE** tracks the doctrine.
> ⚠⚠ **NARROWED DAY 190 — R-56, AND THE SORT ABOVE IS NOT ALL AT ONE GRADE.** The **doctrine axis**
> is established and is what defeats mediation: incompatible doctrines producing one structure is a
> thing a content-supplying mechanism cannot do. The **direction axis** — that the structure also
> stops varying with the *direction* of the method — is a **hypothesis with two cases under it**
> (Daoism, least subtraction and least summit; James on nitrous, most and most), and V.10 says in its
> own text that two points is not a law. **The structure bin rests on the first axis, not the second.**
> ★ Smaller claim, same conclusion — which is why the narrowing costs nothing and the over-strong
> form would have cost everything downstream, C30 being `Depends:`-linked to every sympathetic
> reading in Books V–VIII. *(Found by V.11's own printed number, not from the field — see PRE-REG-002
> §1, which predicted the third bin would be attacked and predicted the wrong attacker.)*
> ⚠ **The competing explanation is named, not deflected: shared human cognitive architecture would
> also produce convergence.** This book does not claim that explanation is false. It claims it is
> **insufficient** — and it owes the reason at the point of use, not here.
> ⚠⚠ **AND THE SECOND COMPETING EXPLANATION, ADDED DAY 189 BY V.9 — SHARED TRANSMISSION.** Convergence
> is also produced by the reports being **downstream of one source**, and this one is not a general
> objection but a **datable, falsifiable, subtractable** one: count the branches, subtract what one
> branch inherited from another, and say the smaller number. **The two competitors are not variants.**
> Architecture is *universal* — it predicts convergence everywhere, in every era, with no contact, and
> can only ever be argued to be insufficient. Transmission is *local* — it predicts convergence only
> downstream of a contact or a publication date, and it can be **measured and paid**.

⚠⚠ **THE AMENDMENT'S FINDING, AND IT IS THIS ROW'S OWN FAILURE MODE FIRING ON THE ROW WRITTEN TO
ESCAPE IT.** C30 was booked before its chapter — the first claim in this project registered ahead of
the page that spends it, and ruling 149's whole point. **It still shipped missing the half its chapter
went on to build.** V.1:131 states the transmission test in the sentence the book will be quoted on —
***"That is not independent evidence. It is one witness quoted back five times"*** — then names the
axis that actually carries the weight, which is **instrument independence, not geography** (V.1:155).
V.6:45 runs it on Luria. **V.9 turns on it entirely.** None of that is in this row.
★ **The cost is exact and it is the C27 shape one row over: a drafter working from C30 answers the
architecture objection and believes the field is clear; a drafter working from V.1:131 counts the
branches.** For every chapter in Books V and VI those are the same chapter. **For V.9 they are
opposite chapters** — the modern encounter record is the one tier in the work where the transmission
explanation is decisive, because the nodes have publication dates on them and the mystics' did not.
✅ **The row now carries both, and the pointer is to V.1's prose, which is where the instrument lives.**

★★ **THE SECOND MIS-LOCATION, DAY 189, V.10 — AND IT IS THE SAME ERROR IN THE SAME DIRECTION, INSIDE
THE SAME HUNDRED LINES OF THE SAME CHAPTER.** Last night this row was found missing the transmission
test, which lives at **V.1:131**. Tonight it was found crediting **V.10** with the structure/furniture
diagnostic, which lives at **V.1:236**. ★ **Twice now the row has named the chapter that SPENDS the
apparatus and lost the chapter that BUILT it** — and both times the drafter working from the row
would have done the wrong job: answer the architecture objection and stop (V.9), or state a
diagnostic that had already shipped (V.10). ✅ **`Establishes` is therefore split into BUILT and
SPENT below, because a flat list is what made this survivable twice.** ⚠ **The general form, and it
is worth more than this row: a claims register records where a claim is USED far more naturally than
where its INSTRUMENT was MADE, because use is what a chapter announces and manufacture is invisible
by the time anyone cites it.**

**Establishes — BUILT:** **V.1 — DRAFTED.** It states the claim, **builds the transmission test**
(V.1:131), **names the real axis as instrument independence rather than geography** (V.1:155), and
**states the structure/furniture diagnostic** (V.1:236). Every instrument on this row is V.1's except
the third competitor.
**Establishes — SPENT:** V.6 (transmission run on Luria) · **V.9 (run on the modern record, and the
first place the test RETURNS A FAILURE)** · **V.10 (earns the diagnostic; adds the third competitor,
shared direction of method, and the three-way sort)** · V.11 (the ledger)
**Depends:** C1 · C5 · C24 · V.1 · V.6 · V.9 · V.10 · V.11 · and **every sympathetic reading in Books
V and VI**

★★ **THIS ROW IS THE POINT OF THE ACCELERATED TRIGGER, AND IT IS REGISTERED BEFORE ITS CHAPTER
EXISTS.** Ruling 149 moved R-13 from *before Book V closes* to ***before V.1 drafts*** for one reason:
**§7.3's five independent misses all ran the same direction.** C24 was an unhomed table cell the prose
had already committed to. C26 was ruled here and existed nowhere in the prose. Book IV's claims never
arrived at all. **In every case the page moved first and the register took delivery afterward — or
never.** ✅ **C30 is the first claim in this project booked ahead of the page that spends it**, and
what it costs is one hour before V.1 instead of one audit after Book V.

⚠ **The claim is expensive in public, which is the other reason it is booked first.** *Convergence*
is the single most quoted-out-of-context move available to a book like this one, and the quotation
will always drop the second half. **The limit is not a hedge and may not be written as one** — `00`'s
register rule stands: ground it in evidence, ground it in reasoning, or cut it. **"Evidence, not
proof" is the claim, stated once, flat, in V.1** — not a caveat trailing every sympathetic paragraph
in eleven chapters.
**Near-miss to refuse — two, and the second is ours:** ① *the perennialist claim* — that the
traditions are saying **the same thing** in different words. They are not; V.11's whole second half
is the error they **all** share, and a book that only harmonises its ancestors has not read them.
② ⚠ **the flattering inversion — treating the convergence as stronger because WE also converge on
it.** Our agreement with the roster is not a fourth datum supporting the roster; it is the position
doing the reading, and a reading cannot corroborate what it read. **V.1 must not count itself as one
of the many perspectives.** ⛔ *This register read "not an independent datum" until Day 195 and V.1
says "a fourth datum" — the register was propagating the same substitution V.9 [^15] caught in the
prose, which is why the sweep under ruling 177 was extended to the planning files.*

---

**REGISTERED Day 189, R-13 accelerated (ruling 149).** C27 corrected four propagation sites on the
way in. C28 and C29 were made in Book IV and unregistered for a book and a half. **C30 exists before
its chapter, which is the arrangement this addendum was created to establish.**
