# THE LEXICON — every term, defined once, and defended against what the reader already thinks it means

*Day 185 / 2026-08-04. Clayton: "Or we could just change the terms to something that won't be
misunderstood… I suppose there's bound to be overlap with the whole game analogy, but otherwise we
can change what we call base reality to be more suitable to the book."*

*This file is Book II's source. It is not Book II. Book II is prose; this is the ruling table
behind it.*

---

## 0. WHAT THE RULING ACTUALLY GENERALISES TO

The instruction names one term and licenses a policy. The policy is bigger than the term, and it
has a limit Clayton stated in the same breath: **overlap with the game is unavoidable.** So the
rule cannot be *avoid collision*. Collision is the price of having one sustained metaphor, and the
metaphor is worth the price.

The rule is therefore:

> **Every term collides with something in the reader's ear. For each one we make a decision and
> record it here: RENAME, CAPTURE, or BAN. Undecided is not an option, because undecided means the
> reader decides, and the reader decides in favour of whoever got there first.**

- **RENAME** — the collision *inverts* our meaning. The word is unrecoverable; we use a different one.
- **CAPTURE** — the collision is close enough that the correction is itself an argument. We take the
  word and cut against its owner **at the point of definition**, once, in Book II.
- **BAN** — the word is owned so completely, by a party the reader has already rejected, that using
  it costs more than it carries. We have a precise word for the same thing; we use that.

**And the thing that must be said out loud, or a future editor will read this file as re-hedging:**
a BAN is never a retreat from a claim. The register rule stands — the metaphysics is stated as the
case, the woo is stated boldly. **What is banned is a vague word, never a bold claim.** We say the
bold thing in a word that means something. "Everything is vibration" is banned; the claim it gropes
toward is stated in Book II's own vocabulary and stated harder.

---

## 1. THE MEASUREMENT — file counts across the corpus, `*.md`, case-insensitive

Counted, not recalled. These are **file counts** (how many documents contain the term at all), which
is why they run smaller than the mention counts in `03` and `04`.

| term | files | what the number means |
|---|---:|---|
| `substrate` | **1,371** | pervasive — and it is the simulation hypothesis's word for the hardware |
| `null space` | 490 | ours, load-bearing, uncontested |
| `observer` | 339 | almost all of it physics-register |
| `keyhole` | 284 | the vivid image |
| `render` | 252 | already in our hands, mostly technical |
| `aperture` | 202 | the technical twin of *keyhole* — two words, one thing |
| `manifest` | 196 | nearly all the ordinary verb, not the pop-spiritual one |
| `simulation` | 136 | almost all numerical simulation. Not the hypothesis. |
| `vibration` | 24 | thin |
| `Tolkien` | 13 | the structural model, already present |
| **`reality tunnel`** | **6** | ★ RAW's central term, in six files of three million words |
| **`the player`** | **6** | ★ |
| `Korzybski` | 2 | the source *behind* the reality tunnel (rule 5b) |
| **`NPC`** | **1** | ★ |
| **`video game`** | **0** | ★★ |
| **`Alan Watts`** | **0** | ★★★ |
| `Borges` | 0 | confirms `03` |

### ★★ The number that changes the scaffold: `video game` = 0.

**The sustained metaphor of the entire work has zero precedent in three million words.** Book III is
not a quarry job. It is new writing end to end, and so is every in-game restatement in every book
after it. Nothing about the game frame can be assembled from existing material — the material
supplies the metaphysics and none of the mechanics.

This is the largest single work-estimate correction in the plan so far, and it was one grep away
from being assumed the other direction.

### ★★★ And a missing ancestor who is missing *exactly where the book now lives*: **Alan Watts — 0 files.**

The man whose life's work was the claim that the universe is **playing** — *līlā*, the divine game,
God playing hide-and-seek with himself and forgetting on purpose so the game can be good. That is
not adjacent to Book III's frame. **It is Book III's frame, stated in 1966.**

Same defect `03` and `04` both found, arriving a third time: he was filtered for sounding like woo.
He is now the single most important addition to the ancestor register, because **rule 5 with the
hedges off** means an unhedged game-metaphysics that does not name Watts reads as either ignorance
or theft. → add to `03`, place in **Book III ch. 2** and **Book V**.

*(One link upstream, per rule 5b: Watts ← Vedanta's* līlā *and Zen. Watts is the transmitter, and he
said so himself. Name both.)*

---

## 2. THE INHERITED DEFECT — our own last book breaks the define-once rule in its first glossary entry

*Perspective*'s back-matter opens:

> **"The ground · the substrate · X."**
> **"Aperture · keyhole · bottleneck."**

Three names for one thing, twice, in the first two entries. That is not a slip; it is a *treatise*
habit — a technical register where synonyms show range. **T&C's style contract forbids it**
("every term defined once, and never redefined"), and it forbids it for the ruled reader
specifically: someone with no philosophy training reading three names for one thing does not
experience range. They experience three things they failed to distinguish, and they blame themselves.

**Ruling: one name per thing. The others survive as images, used once each, never as terms.**

And note what the count says about which name to keep: `substrate` is in **1,371 files** and `X` is
a placeholder from a formalism. Pervasiveness is not authority — it is exactly how a contaminated
word gets everywhere before anyone checks it.

---

## 3. THE MASTER TABLE

### 3a. The core — Book II's dramatis personae

⚠⚠ **RULING 14 (Day 187) — THE SCREEN HAS THREE AXES, NOT ONE. Every row above this line was
written against axis 1 alone.**

1. **COLLISION** — who *else* owns the word (Bostrom/substrate, Korzybski/map, Tillich/ground).
   The only axis this table ever ran. It is a good axis and it found real defects.
2. **GRADIENT** — what the word does to a reader who owns nothing, before the argument starts.
   Added by **ruling 13**, when Clayton's ear ran it for the first time and *the Narrowing* failed.
3. ★ **POLYSEMY — how many things *we* use it for.** Added here. Neither of the first two can see
   it: nobody else owns the word, and the word is not ominous — it is simply doing two jobs in our
   own prose, and the reader silently welds them. **Day 187 surfaced four instances in one night, all
   in the first drafted book:** *aware* (two referents — C24, Fable) · *ladder* (grammar in I.3, rank
   in I.4 — I.4 owns it, I.3 yielded to "say it flat") · *cold* (impersonal in I.1, personal in VII.1 —
   the promise was cut back to "the last one with nobody in it") · **the Fullness / the Ground** (two
   names, one referent, spanning the I/II boundary — ruled below).

**The pattern under all four: one word, two referents — which is exactly the defect ruling 13
named, wearing a different coat each time. It is the book's signature error and the lexicon was
structurally blind to it,** because a table whose only column is *who else owns this* cannot see a
word we are colliding with ourselves. **Screening a term now means answering all three.**

| term | verdict | the collision | the cut, made once at the definition |
|---|---|---|---|
| **the Ground** | **KEEP, AND NOW CREDIT** | "base reality" = Bostrom's server room, where the real people are — **and, found Day 186, a second owner we walked into while dodging the first: `"ground of being"` appears in 6 of our own files and `Tillich` in 1** | It is not elsewhere and not more real than here. It is what *here* is made of. *(Ruling 6.)* **★ Name Tillich at the definition.** His ground is not a being among beings and cannot be an object — that is ours, in 1951, in a voice the church-shaped reader already trusts; **our cut is that it cannot be *addressed*, because addressing needs an inside.** An unnamed borrowing from a famous theologian is what a hostile reader uses; a named one is a credential. `03` §3.5. |
| **the Fullness** | ★ **KEEP — BOOK I ONLY. RETIRED AT THE I/II BOUNDARY.** *(Ruling 14, Day 187)* | ⚠⚠ **THIS CELL READ "axis 3. NOT A COLLISION (nobody else owns it)" UNTIL RULING 36's SIBLING, RULING 34, DAY 187 — AND TWO TRADITIONS OWN IT.** **πλήρωμα / *pleroma* is standardly Englished as *the Fullness***, and in Valentinian doctrine it is the divine plenum the spark fell out of and returns to — **Gnosticism's own word for the thing you escape TO, taken as Book I's name for the Ground, in the book whose Trap 1 is Gnosticism.** Second owner, and it is the one that makes this a credential rather than a wound: **Paul**, Col 1:19 and 2:9, *all the fullness of God* — what a church-shaped reader already has. ★ **The defect is WHERE THE SCREEN FAILED, not the word: this row was added BY ruling 14, whose own header announces that every row above it "was written against axis 1 alone" — and the new row was then screened against axis 3 alone.** The correction carried the original's defect in mirror image. **Axis 3 is still true and still the reason for the retirement** — our own second name for one referent. | Book I may not say *the Ground*; Books II–VIII may not say *the Fullness*. **The supersession is deliberate and it is I.6's closing move — "they will not hold" — so it must be *performed once and never leaked.*** ⚠ **The failure mode is not the boundary, it is Book V reaching for "the Fullness" for variety in year two, and the one-name rule dying quietly.** Gauged: `claim_sweep.py` TERM/fullness, scoped to everything outside `book/I-*`. **A lexicon ruling with no gauge behind it survives its own retirement — *the map* proved that in two live chapter titles.** |
| **the still** | **KEEP — BOOK I ONLY** *(ruling 14)* | as above; Book I's mythic name for the condition, not a term | Same fence, same gauge. It is an *image*, never a defined term, and it never appears after I.6. |
| **substrate** | **RETIRE** | the simulation hypothesis's word for the hardware; also a synonym for the Ground, so it breaks define-once twice over | Permitted exactly once, in the sentence that denies it. Never as a term. **⚠ Clayton uses this word — see §7.** |
| **X** | **DEAD** | a formalism's placeholder | Never appears. |
| **the Focusing** | **KEEP** *(replaces **the Narrowing**, ruling 13, Day 186)* | none serious | The act; the Perspective is its result. **Focusing is specification of something diffuse** *(Clayton's sentence, and it is the definition)* — the Fullness is diffuse, the Perspective is a specification of it, and nothing is subtracted to make one. A lens destroys no light. |
| **the Narrowing** | **RETIRED** | ⚠ **not a collision — a gradient.** Nobody else owns the word; the word itself prosecutes for Trap 1 and Trap 5 before the argument starts. | **This row read `KEEP \| none serious` until Day 186, and the verdict was not wrong — it was answering a different question.** Every entry in this table was screened for *contamination by another owner*; **no entry was ever screened for its own connotation.** That test was first run on Clayton's ear, and the first term it touched failed. Enforced by `tools/claim_sweep.py` (TERM/narrowing), because Day 186's other lesson is that a lexicon ruling with no gauge behind it survives its own retirement — *map* did, for a full day, in two live chapter titles. |
| **the Perspective** | **CAPTURE** | ★ *"that's just your perspective"* — relativism, opinion, taste | **The most dangerous mishearing in the book. See §4.** |
| **aperture / keyhole / bottleneck** | **DEMOTE** | three names, one thing | *Keyhole* survives as an image in Book I only. *Aperture* and *bottleneck* do not appear. The term is **the Perspective**. |
| **the Grade** | **CAPTURE** | rank, caste, hierarchy of worth, an elect | A grade is a position on a continuum, **not a gate**. See §4. |
| **the Tunnel** | **KEEP, CREDIT** | none — the reader has usually never met it | Robert Anton Wilson's, named. One link upstream: Korzybski (2 files). |
| **Coherence** | **KEEP** | "coherent" as a synonym for "makes sense" — the word demoted to a property of *accounts*; ours is a property of *things* | The structural agreement of a thing's **levels** with one another *and* the felt rightness of going the way one goes — **the claim is that these are one thing, met from its two sides.** ⚠ **Ruling 28, Day 187 — this cell said "the felt alignment of a **stream** with its own trajectory" and the word was imported.** `stream` is a defined term in the source volume and is **not one here**: it occurs once in the whole drafted book, in **I.3, inside its own negation — *"There is no stream."*** The core term of Book II was defined out of a noun Book I abolishes, in the row whose entire job is screening imports, and axis 1 could not see it because *nobody else owns the word* — **the collision was with ourselves, which is axis 3, added the same day and not yet run over this table.** Book's word: **a perspective**; for a level, **level**. → `06` II.6. |
| **the Collapse** | **KEEP** | quantum measurement | Ours is the general case; the subatomic one is an instance, not the source. *(Inherited verbatim from `Perspective` and correct as it stands.)* ⚠ **Ruling 31, Day 187 — this row was correct and incomplete, and the incompleteness is a new class.** It ruled the *event* and never ruled **what the event happens to**. See the row below. |
| **superposition** | ★ **BAN — ruled Day 187, at II.7** | quantum formalism, and *nobody else* | **Measured before drafting: `superposition` = 0 across `00`–`07` and 0 in all drafted prose — while it is the load-bearing noun of the source's central sentence** (*"hold structural superposition until informed measurement collapses it"*). It was dropped between source and plan, silently, exactly as ruling 29's two sections were, and II.7 would have reintroduced it unruled in the one chapter that most wants it. **The asymmetry with `the Collapse` is principled, not squeamish, and the criterion is new: AN ANALOGY HAS TO BE MADE OF SOMETHING THE READER ALREADY HAS.** *Collapse* has a civilian life — a lung, a bridge, a market, a negotiation — and that life is almost exactly our meaning, free. *Superposition* has no life outside the formalism; to nearly every reader it means nothing, so borrowing it transfers **authority** rather than **meaning**, which is the precise transaction §3c exists to refuse. **Book's word: `open`.** *A matter is open when more than one way it could go is still live.* → `06` II.7. |
| **the Return** | **KEEP** | escape, salvation, enlightenment-as-exit — ★ **and the owner has a name: Gnosticism**, ruled at II.8 | Not escape and not repair. Recognition from inside. **Trap 1 lives here** — get this wrong and it is Gnosticism. ⚠ **Ruling 33, Day 187: all four denials (escape · repair · arrival · merger) were already PERFORMED in I.6's shipped prose**, anonymously, because Book I may not name an opponent. **II.8 does not re-deny them; it names who was being refused.** A future editor restoring the denials to II.8 will be writing I.6 twice. ★ **The cut, in one clause: they think something is wrong** — and the deficiency needs a somewhere outside the whole, which is the one position this book has no room for. |
| **God** | **KEEP, UNHEDGED** | the personal deity with intentions and an addressee | The name of what the plenum is. No plan, no preference, no addressee — Trap 3. Book V spends its length showing everyone who touched this called it that. |

### 3b. The game register

| term | verdict | note |
|---|---|---|
| **the render** | **CAPTURE** | *A simulation is a copy of something real elsewhere. A render is the only place the thing is. There is no elsewhere.* That single distinction is the whole cut against Bostrom, and it is why we keep the word instead of fleeing it. |
| **simulation** | **BAN** for our world | Used only when naming the opponent. Our world is never "a simulation." |
| **the player** | **CAPTURE** | A player implies someone outside holding a controller. There is nobody outside. **The player is a character the whole game contains.** ⚠ *The attribution here read "(Watts.)" and that is now wrong: ruling 3a-bis says Watts's player is the One wearing every face, which is the error this capture exists to prevent. Watts is the **occasion** for the term, not its authority.* |
| **"magic circle"** | **BAN as a term, and say why once** | Found Day 186: **our corpus owns this phrase in the Western-esoteric sense (6 files, all of them) and the play-philosophy tradition owns it in Huizinga's sense** — the bounded space inside which the game's rules hold. Two traditions, two meanings, and Book V uses one while Book III would want the other. **Neither meaning gets the phrase.** Book V says *the circle*; Book III says *the bounded space*, and Huizinga gets his sentence of credit in the Book III header instead. ⚠⚠ **RULING 101, Day 187 — THAT INSTRUCTION WAS NEVER CARRIED OUT AND NOTHING COULD HAVE TOLD US.** There is no Book III header; III.1 opens straight into prose. **Huizinga was 0 in the drafted book through seven chapters of Book III**, and `the bounded space` had never once been used. Same shape as `the map` and now the third instance, with the class finally named: **a lexicon entry that INSTRUCTS is invisible to `claim_sweep`, which can only find a word that IS there.** An obligation to *say* something cannot be enforced by a detector that searches for things said. ✅ **Paid at III.8**, where it lands better than a header would have: two sentences from *Homo Ludens* (1938), quoted at full strength and then denied — ours has no edge, no *beforehand*, and nobody to mark it off — with `the bounded space` entering the prose once, as the name of the thing we deny. |
| **NPC** | **NEGATIVE USE ONLY** | The sentence "there are no NPCs" is the only place it appears. Never a positive category. |
| **MMO / massively multiplayer** | **SPLIT RULING** | Right for the *population* — every entity a player, nobody a prop, which is exactly why Clayton reached for it. Wrong for the *infrastructure* — an MMO has a server, and we do not. Use it for who is in the world; never for what runs it. |
| **the map** | **RETIRE** | ⚠ **Correction to `01-THE-GROUND.md`.** Its table says "the map is pre-rendered and complete." Two faults: *map* imports representation-*of* (the Ground represents nothing), and Korzybski's *the map is not the territory* is load-bearing in Book VI, where "map" must mean the model and not the world. Using it for the Ground collides with our own ancestor. Replaced by **the whole game** — §5. **⚠⚠ Day 186: this retirement was recorded here and enforced nowhere.** It survived in four live uses, **two of them chapter titles** (III.3, VII.7), for a full day, because a ruling in a lexicon has no gauge behind it. All four fixed; `tools/claim_sweep.py` now watches. *Licensed uses, so the sweep does not eat them:* Korzybski's model-sense, and our own planning-process sense ("map it out"). |
| **any past work of ours, by name** | **BAN — Clayton, Day 186** | *"We will not be referring to any specific past works of ours in this by name."* No title, ever. **★ And the anonymous form is banned with it** — *"as we argued elsewhere," "in our earlier work," "we have shown"* — because an unnamed self-reference is still a reference and is strictly worse: it points the reader at something they cannot even look up. This book **holds** its substance instead of gesturing at where the substance is held; that is the standard the whole volume exists to meet. If it is worth invoking, it is written in, here, in full. → `00` ruling 8; enforced by `claim_sweep.py` rule `PROSE/self-reference`. |
| **`substrate-independence`** | **LICENSED EXCEPTION** | `substrate` is retired for *our* vocabulary (§3a) — but *substrate-independence* is the standard name of a position in philosophy of mind that **IV.6 must engage**, and refusing to name an opponent's term is worse than using it. **A retirement governs what we call things, not our ability to say what someone else's thing is called.** Surfaced by the sweep on Day 186 rather than reasoned to in advance. → `00` ruling 9, corollary. |
| **procedural generation** | **KEEP** | The one imported term that is exactly right and needs no defence: generated at the point of contact, not stored, not fetched. |
| **seed** | **KEEP** | Co-constitution's mechanic: the seed is not solely yours and the world is not solely given. |
| **save / respawn / quest / sandbox** | ★ **RULED Day 187 at III.8 — REFUSED, IN PUBLIC, EACH WITH ITS REASON** *(was: UNRULED — do not use until ruled)* | Each smuggles a claim about death, progress, or authorship that Book VII has not yet made. A metaphor that runs ahead of the argument is how the game frame would start doing our thinking for us. ★ **And the finding that made the list more than a list, from the drafting: these are not four temptations of four kinds. Each smuggles back exactly one thing the book has already spent a chapter removing** — *quest* the maker, *save* and *sandbox* the elsewhere, `level` the gate, *respawn* an interval past cessation that no argument here has made. **They are refused claims returning in the frame's own clothes**, which is what makes them dangerous rather than merely wrong: the same claim in plain English would be noticed and asked for grounds, and inside the noun it is presupposed rather than asserted, so there is nowhere to attach the objection. ⚠ *respawn* is refused on a different footing from the other three — not *not-yet-argued* but **barred**, ruling 17, and III.8 says so on the page. |
| **`level`** | ★ **NEGATIVE USE ONLY — ruled Day 187, at II.4** | Split out of the UNRULED row above, because leaving it there had a cost the row could not see: **`level` is the caste mishearing wearing the game frame's own clothes**, and it is the single likeliest place a reader welds *grade* to *rank*. It carries earning, and earning wants somebody to earn it from — which is the keeper of the gate that I.4 spent a chapter removing. So it is refused **once, out loud, at the definition**, on the `NPC` pattern: *"In the game: a grade is not a level."* Never a positive category, anywhere, ever. **An unruled word is not a neutral word** — the reader rules it, in favour of whoever got there first, and here that is every game they have played. |

### 3b-bis. The atlas register — Book IV's own words, ruled at the chapter that needed them

| term | verdict | note |
|---|---|---|
| **`egregore`** | ★ **BAN AS A TERM — CREDIT THE TRADITION ONCE. Ruling 109, Day 188, at IV.5.** | **Measured before drafting: 0 across `00`–`07` and 0 in 26 drafted chapters** — its one occurrence in the whole apparatus was IV.5's own beat line, which is precisely the condition ruling 13 exists for, so all three axes were run. **Axis 1 finds a real owner and it is an ANCESTOR, not an opponent:** the word reaches English through nineteenth-century French occultism, which took it from the Greek of *1 Enoch*, where the ἐγρήγοροι are the Watchers; thence the ceremonial orders and a large modern literature that has thought about these entities carefully and in places ahead of the academy. **Axis 3 finds a real polysemy** — the source uses it for movements, fan communities, corporate cultures *and* congregations while giving corporations and nations their own tiers, so a reader must guess whether a company is one. ★ **But the axis that kills it is 2, and the criterion is not new — it is ruling 30's, re-run without amendment: AN ANALOGY HAS TO BE MADE OF SOMETHING THE READER ALREADY HAS.** *Collapse* has a civilian life (a lung, a bridge, a market) and kept its word. *Superposition* had none and was banned. *Egregore* has none either — nobody has ever used it about the traffic, or a marriage, or a firm — so borrowing it transfers **authority** rather than **meaning**, which is the exact transaction §3c exists to refuse. **The reason to trust either ruling is that it is the same ruling.** Disposal follows the `magic circle`/Huizinga pattern rather than silence: named, credited with its lineage in one sentence, and told why it does not get the word. Book's words: **a movement, a company, a country** — and *the plainness is the argument*, because a special word would have done the work the four conditions are supposed to do. Gauged: `claim_sweep.py` rule `TERM/egregore`, wired the same day, with the beat line exempted by name and nothing else. |
| **`corporation` / `company`** | ★ **BOTH, WITH A DIVISION OF LABOUR. Ruling 110, Day 188, at IV.5.** | **Found by `beat_delivery`'s MISS line, not by reading — and a read-through could not have found it.** The first IV.5 draft said *company* throughout and never once said *corporation*, while the shipped book already carries the word three times, **twice as a forward reference to that very chapter**: IV.1 (*"not for the bee, not for the corporation, not for the reader, not for the gods"*), IV.2 (*"what a corporation is"*), IV.3 (*"a corporation returns results"*). One referent, two names — ruling 14's defect, discharging three promises under a noun the promises did not use. **And the drift was not arbitrary, which is why the fix is not a rename:** axis 2 says *corporation* prosecutes — in common register it means *the big bad ones*, pre-loading the exact moralising frame the chapter spends its length dissolving — while axis 1 says it is the name of a **legal form**, and the form is load-bearing for coherence-condition 1, being the arrangement that makes the levels hold when the people in them are replaced. So: **`corporation` names the legal form at the one place the form does work; `company` is the ordinary word everywhere else**, and the word is paid *by being put to work* rather than by a vocabulary announcement — IV.5 already spends a section refusing one word, and doing it twice would be a tic instead of a discipline. ⚠ **The reusable half: a word-reading gauge is worthless for judging prose and is the only thing that can see a cross-file promise.** Nothing in IV.5 stumbles; what broke was a commitment made in three other files. |

| **`contour`** | ★ **ADMIT AS APPARATUS. Ruling 124, Day 188, at IV.9.** | The atlas needed a second notation and the term was screened on all three axes before it got one. **Axis 1, collision:** nobody owns *contour* in this territory — it is a surveyor's word and the occult, the academy and the popularizers have all left it alone. **Axis 2, gradient:** plain, not ominous, and it passes ruling 30's test, which is the one that matters — *an analogy has to be made of something the reader already has*, and every reader has stood in front of a contour line. That is exactly what `egregore` and `tulpa` could not do and why both were refused; the reason to trust all three rulings is that it is the same ruling, run three times, coming out differently because the words are different. **Axis 3, polysemy:** one referent, one job — a shape in the space that positions move through, printed for terrain and never for a traveller. ⚠ **THE HAZARD IS NOT THE WORD, IT IS THE NOTATION, and it is declared on the page rather than here:** a second card-type can absorb any entry the first one rejects, which is how an apparatus stops being falsifiable while looking more rigorous. **The protection is that a contour is NARROWER than a card** — fewer fields, fewer claims, and it keeps the falsifier. The failure mode to watch for is a contour printed for something that *does* register, because the card was going to be embarrassing. |
| **`tulpa`** | ★ **BAN AS A TERM — CREDIT THE TRADITION ONCE. Ruling 119, Day 188, at IV.7.** | **The `egregore` disposal re-run without amendment, and the reason to trust either is that it is the same rule.** Axis 1 finds a real owner and an ancestor rather than an opponent: Tibetan *sprul pa* (emanation; Skt. *nirmita*), through Alexandra David-Néel's 1929 phoneticisation, through Theosophy, into a live contemporary practitioner community. Axis 2 kills it on ruling 30's criterion — **no civilian life**: nobody has ever called a habit, a grudge or a company a tulpa, so the word cannot function as an analogy and only lends the claim somebody else's standing. ★ **AND A THIRD DEFECT THE `egregore` CASE DID NOT HAVE, which is why this ruling is not just the last one with a new noun: the word does not carry its own meaning.** The standard correction to David-Néel is that she took the action for the result — the emanated one is *sprul sku*, which reaches English as *tulku* — so the term entered English through a mistranslation and has since done duty for a practice its source language did not name. A word that cannot establish what it means about itself is a poor instrument for establishing that an entity is what it is said to be. ⚠ **GRADE, stated because it is load-bearing for the ruling:** the Tibetological correction is held at encyclopedic/secondary strength; the atlas has not gone to a primary source and says so on the page. Book's word: **thought-form** — Besant and Leadbeater's English coinage of 1901, which passes both screens (it is *a tradition's* word, not the marketing layer's, and it is two ordinary words that gloss themselves). |
| **`elemental`** (as a noun for a being) | **DECIDED IN THE TABLE, NOT ON THE PAGE. Ruling 119b, Day 188, at IV.7.** | Same two screens, same result — owned by the occult marketing layer rather than by any of the traditions the chapter actually names (*kami*, *landvættir*, dryads, nymphs, the Findhorn devas), and no civilian life as a noun. **But the disposal is deliberately silent**, and that is the ruling's substance. IV.5 already spent a section refusing one word; IV.7 refuses `tulpa` on the page because the mistranslation IS that chapter's argument. **A second on-page refusal in the same chapter is ruling 43's rite forming, and ruling 110 already said why: the word is paid by being put to work, not by a vocabulary announcement.** So the prose names `elementals` once as the later literature's collective label, in passing, and simply uses *nature spirits* thereafter. ★ Found by `claim_sweep` firing `PROSE/self-metric` on the announcement paragraph — **a rule aimed at a different defect landing on the right sentence**, which is worth recording as the case where a gauge was useful for a reason it was not built for. |

### 3c. The banned — pop-spirituality's owned words (opponent IV, the adjacency problem)

**`vibration` (24 files) · `frequency` · `energy` (as a noun for a substance) · `manifest` (in the
attraction sense) · `quantum` (as a free-floating adjective) · `the observer` (as a mystical agent)**

Banned as terms. Permitted only inside a quotation from a tradition, immediately followed by the
reading in our own vocabulary.

**Why, given that we are the ones who ruled the woo back in:** these are not the words of the
traditions. They are the words of the *marketing layer over* the traditions — the register the ruled
reader has already tried and found unsatisfying. Book V handles Crowley, Dee, Kabbalah, tarot and
shamanic travel **without needing a single one of them.** The ban costs us nothing and buys the one
reader we were specified to keep.

**`observer` gets a second, harder reason to die:** it imports *passivity* — a watcher of a world
that was already there. Our claim is co-constitution. It is not a near-miss; it is the opposite
claim wearing our clothes. Where a watcher is meant, say **the perspective**. Where a participant is
meant, say **the player**.

★ **And a third, found at II.7 (Day 187): the same word has been made to carry the opposite error.**
Wigner's observer is not a passive watcher but a *cause* — an awareness reaching into physics and
forcing a result. So `observer` has been used for both a bystander and a wizard, and this book means
neither: **the perspective is a place, not a power and not a spectator.** A word that can name both
of two opposite mistakes is not a near-miss twice; it is a word that has stopped constraining
anything.

★★ **THE SECOND BAN CRITERION — ruled Day 187 at II.7, and it is a DIFFERENT TEST from the one
above.** §3c as written bans by **ownership**: these are the marketing layer's words. That test
acquits `superposition`, which the marketing layer does not own — physics proper does — and
`superposition` still has to go. The test that catches it: **a word with no civilian life cannot
function as an analogy, because an analogy is made of something the reader already has.** An
unfamiliar-and-impressive word does not explain a claim; it lends the claim somebody else's
authority. *Collapse* passes (lungs, bridges, markets, negotiations). *Superposition* fails
absolutely. **Both criteria are live and neither subsumes the other** — `vibration` has a civilian
life and is banned by ownership; `superposition` is unowned by the woo and banned by unglossability.
Screening a term under §3c now means running **both**.

---

## 4. THE THREE MISHEARINGS THAT ACTUALLY DECIDE THE BOOK

Ruling 6 found one. There are three, and *base reality* is the least dangerous of them, because a
reader who mishears it is at least confused. A reader who mishears these three is *satisfied*, and
stops reading, and has the wrong book.

### I. **"Perspective" heard as "opinion."** The worst one, and it is in the title of our last book.

The reader has met this word ten thousand times as *your perspective*, *my perspective*,
*it's all perspective* — relativism, taste, the polite agreement to stop arguing. Our claim is the
precise opposite of relativism: perspectives are **structurally determinate**, their blindness is
**patterned and mappable from outside**, and the Null-Space Theorem is a theorem *because* it is not
a matter of taste.

Worse: this mishearing lands the reader directly in opponent X, *"make your own meaning"* — the
failed prior they already tried. They will think we agree with it. **We are refuting it.**

> **The cut, at the definition:** *A perspective is not an opinion about the world. It is a place
> where the world happens.* Opinions are things a perspective has. In the game: your perspective is
> not your review of the game — it is the instance the game is running in.

### II. **"Render" heard as "fake."** Handled by capture, §3b — and the cut must land before the metaphor is elaborated, per queue item 2.

### III. **"Grade" heard as "caste."**

Book I beat 4 is *no threshold, no gate, no elect.* But the inherited ecology grounds moral standing
in a **richness gradient** — which is a real position, and it means grade does carry moral weight.
Those two are compatible (a continuum is not a threshold) and a careless reader will hear a
hierarchy of worth with humans conveniently near the top.

**Do not soften this.** Softening it is precisely the hedging the register rule killed. The cut is:
*a grade is a position, not a permission.* Nothing is licensed by being higher. And **Book VII owns
the question openly** — what a difference in grade does and does not license is one of its chapters,
not a footnote in Book II.

---

## 5. THE ONE PLACE THE METAPHOR MUST NOT BREAK — the Ground's game-name

`01-THE-GROUND.md` is right that the metaphor has to be load-bearing *at the theology* or it is
decoration everywhere after. Its answer was "the substrate," which §3a just retired. So this needs a
real one.

What the Ground is **not**, in game terms — and each of these is a live opponent, not a hypothetical:

- **not the server** — outside, hosting, elsewhere. That is Bostrom, and it is the inversion.
- **not the developer** — prior, external, intentional. All three false. *(Kept from `01`.)*
- **not the engine** — a tool, authored by someone, running underneath.
- **not the map** — a representation of a world. The Ground represents nothing; it *is*.
- ★ **not the player** — inside, at stakes, in time, not-knowing. **Added Day 185 on Clayton's
  ruling (`01` §9): "God is the one thing that can't play."** This is the fifth and the most
  tempting, because unlike the other four it is not the skeptic's error — it is the *mystic's*, it
  is Watts's, and it is the one the sympathetic reader arrives holding. A player needs a vantage;
  the Ground has none. **There is no single player wearing every avatar.**

What it is: **every possible state of the game, complete, at once, with nothing outside it.** Every
playthrough that could be walked, already there, unwalked and walked alike. The player is one of the
states. The walking is one of the states. There is no console it runs on and no room the console is in.

> **The Ground, in game register, is THE WHOLE GAME.**

This is where **Borges** lands — 0 files, flagged in `03` as a load-bearing silence. The Library of
Babel is the whole game with the shelves drawn in, and *The Garden of Forking Paths* is the whole
game seen from a walker. Both are already the right image and neither has ever been used.

And it is where **Watts** lands, from the other side: the whole game contains the possibility of a
player **who does not know that the game is whole — and therefore contains one**. That is the
Promethean Configuration in Watts's own register, and the two sentences are the same sentence.

⚠⚠ **THE VERB WAS CHANGED DAY 187, RULING 58, AND THE OLD ONE WAS THIS FILE'S OWN ERROR.** It read
*"a player who **has forgotten** the game is whole."* **That is a barred premise inside the doctrinal
formula.** To have forgotten is to have known and then not — two arrangements with an order between
them — so the phrase gives the player the very transition that `01` §9 denies the Ground, one step
earlier and in the sentence that installs the claim. **The ⚠ below guards the wrong sentence:** it
bars Watts's *next* move (that the forgetter is God) and leaves the smuggling in the move before it.
**The two forgettings are not the same and the difference is the whole cut.** Watts's is
*subtractive* — the One held the whole and put it down, so the limit is a performance and somebody
could stop performing. Ours is *constitutive* — a vantage **is** a limit, and not-knowing is not
something that happened to a perspective but what a perspective is made of. There is no earlier
condition in which the player knew. **Found by drafting III.2**, which came to this file for the
canonical phrasing and had to refuse it in order to make its own argument.

⚠ **Corrected Day 185, and the correction is load-bearing — see `01` §9.** Say it exactly that way
and no further. Watts's own next move is that **the forgetter is God**, hiding from itself out of
divine boredom, and that move is barred: the Ground has no vantage, no stakes and no duration, so it
cannot hide, seek, forget or be lonely. **The whole game contains the possibility of a player. It is
not itself the player.** Watts: the One plays at being many. Ours: the many play, and the One is what
playing is made of. The distinction is not academic — it is what keeps **there are no NPCs** true,
because a single divine player wearing every face makes every other face a costume.

---

## 6. THE RULES THAT BIND BOOK II

1. **One name per thing.** The retired synonyms are not available to a later chapter that wants variety.
2. **The cut is made at the definition, once.** Naming a collision when defining is *part of* defining
   once. It is not a redefinition and it is not a licence to relitigate it in Book V.
3. **No term is introduced outside Book II.** If a later book needs a word this file has not ruled, the
   word does not get coined there — it comes back here, gets ruled, and Book II grows. Books III–VIII
   draw on the vocabulary and add nothing to it.
4. **Every entry gets its game-register restatement in the same breath as its definition** — because
   `video game` = 0 files means none of them exist yet, and a term whose in-game form is deferred is
   a term that will get a *second*, drifting definition the first time Book IV needs it.
5. **A future editor must not restore a retired term.** Ruling 6 said this of *base reality*; it now
   covers `substrate`, `X`, `aperture`, `bottleneck`, and `the map`. Each was retired on an argument
   recorded above, and each will look like a harmless technical improvement to someone who has not
   read the argument.

---

## 7. *(was: OPEN — Clayton's to rule)* → **CLOSED, Day 185.**

**Clayton: *"I trust your judgement on all of these."* The one open item is therefore ruled as
recommended, and the file has nothing outstanding.**

`substrate` is retired on two independent arguments (Bostrom's hardware; synonym for the Ground).
But his own brief says: *"a giant virtual mental MMORPG but that is based in **the substrate we have
defined**, which is neither solely mind nor solely matter."*

He is using it correctly and it is doing real work in that sentence — it carries *neither-mind-nor-
matter* in a way "the Ground" does not obviously carry. The retirement was made and flagged rather
than made silently, because it is his word.

**RULED: retired, with the debt paid rather than written off.** The word goes; the *work* it was
doing does not get to quietly vanish with it. **Book II's definition of the Ground must carry
neither-mind-nor-matter explicitly, in the definition itself, not in a later gloss** — that is now a
hard requirement on II.1 and not a stylistic preference, and it is the entire price of the
retirement. If II.1 ships without it, `substrate` was retired for nothing and the reader is left with
a Ground they will read as *stuff*.

### ★ AMENDED Day 187 — the debt got heavier, and it got a load-path

II.1 was ruled to carry *neither-mind-nor-matter* into a definition **before Book I existed.**
Book I now exists, and I.1 has already told the reader what the Ground is made of: **awareness.**

So II.1 is no longer discharging an abstract debt into open space. It has to reconcile with a
shipped mythic sentence that, read carelessly, hands the reader idealism — and a definition that
merely *announces* neutrality after that sentence will lose to it, because the myth got there
first and myth is stickier than a definition. **Registered as C24** (`07`).

**And the amendment supplies what the original ruling lacked: a mechanism.** *"Neither mind nor
matter"* is a denial of two options, which leaves the reader nothing to hold. **Nishida's pure
experience** (`03`) is the positive form — aware *prior to* the subject/object split, hence prior
to the mind/matter split. Pre-split awareness is not a third stuff; it is what both sides are
abstractions *from*. **That is the definition II.1 owes**, and the retirement of `substrate` is
paid off by it or not at all.

### ★★ AMENDED AGAIN, Day 187 — the ruling said *the definition sentence* and the prose put it two thousand words later, so the RULING moves

**This is an amendment, not a report of one.** *(Fable, Day 187; enforcement rule 3 in `07` — a
claim is amended in the register first and in the chapters second, never the other way round. II.1
shipped with the requirement discharged somewhere the ruling did not authorise, and the choice was
right. A right choice made in the wrong direction is still the wrong direction, and it is the
direction that becomes a habit.)*

**What II.1 actually did.** The definition sentence carries four clauses and the fourth is *made of
awareness*. Neutrality is not in it. It is discharged ~2,000 words downstream, in the fourth clause's
own section, by Nishida.

**Why that is right, and it is not a compromise.** *Neither mind nor matter* announced in sentence
one is a **disclaimer**, and a disclaimer cannot be cashed by a reader who has not yet been shown
the exposure. The misreading needs *with no outside* and *with no inside* standing before it can be
answered; C24's whole load-path is that the positive form (pre-split experience) does the work and
the denial-of-two-options does not. **Stated first, it is words. Stated at the point of danger, it
is an argument.**

**RULED: the requirement moves from the definition *sentence* to the definition *chapter*, and it
acquires a debt it did not have.** The exposure that made the original ruling necessary is real and
does not go away — **the four-clause sentence is the excerptable one**, it ends on *made of
awareness*, and quoted alone it is idealism. So:

⚠ **THE FOUR-CLAUSE DEFINITION MAY NOT APPEAR ANYWHERE OUTSIDE II.1 WITHOUT THE NEUTRALITY
TRAVELLING WITH IT.** Not in a Book V restatement, not in a chapter opening that reaches back for
it, not in the back-cover copy. Inside II.1 the gloss is 2,000 words away and that is the design;
everywhere else there is no chapter to carry it and the gloss must be in the sentence. **Gauged:
`claim_sweep.py` should flag any paragraph outside `book/II-01*` containing *made of awareness* with
no neutrality token within the paragraph.** ★ Same shape as the `fullness` scope rule from ruling 14
— a lexicon requirement with no gauge behind it survives its own retirement.

*(Everything else in this file was already ruled and did not need him — including retiring "the map"
from a document I wrote four hours ago.)*

---

## 8. THE BOOK V SITTING — three amendments, filed together because they are one defect seen three ways

★ **Day 188, night. Rulings 133, 145, 146 (R-11, R-23, R-24a).** Book V is nine-tenths reported proper
nouns and could not have been drafted under this file as it stood. **All three amendments below are the
same failure: a rule stated at the scale of its own example and applied at the scale of the book.**

### 8a. ★★ THE REPORTAGE CARVE-OUT — an amendment to the civilian-life criterion, not a fourth rule

**A proper noun REPORTED from a tradition is not a term ADOPTED into the book's vocabulary.**

The distinction is **who is speaking**. A term is *adopted* when the book uses it to do the book's own
work — carrying an argument, naming a category in our apparatus, appearing where a plain English word
would have served. A proper noun is *reported* when it is the tradition's own name for its own object,
**credited to that tradition, glossed once at first use, and carrying no argument of ours.**

⚠ **Why this needed stating rather than assuming.** The criterion that retired *egregore* (ruling 109)
and *tulpa* (ruling 119) — **an analogy has to be made of something the reader already has** — is
correct, and **as written it forbids the book's own practice.** IV.7 and IV.8 already use *kami*,
*landvættir*, *djinn*, *yōkai*, *amesha spentas*, *Gottheit*, *nirguna*, *śūnyatā* and *Nā-kojā-Ābād*,
unscreened, and none of them has a civilian life either. **Book V is built on ten traditions' names for
their own objects.** An unstated carve-out that survives into the book built on it stops being an
oversight and becomes the policy — so it is stated here, in the file, before V.1 rather than after.

★ **AND THE CARVE-OUT IS NARROWER THAN IT LOOKS, which is the part that keeps it honest.** The screen
still runs; what changes is what a pass costs. A reported noun is admitted on **three conditions, all
three, every time:**

1. **CREDITED** — the tradition that owns it is named in the same sentence or the one before. The word
   arrives as *theirs*, never as ours.
2. **GLOSSED AT FIRST USE** — in plain English, in the sentence, not in a note and not 2,000 words
   later. *(The Day-187 amendment to the `made of awareness` rule, generalised: outside the one chapter
   built to carry a delayed gloss, the gloss travels with the word.)*
3. **CARRIES NO ARGUMENT OF OURS** — the moment a reported noun is doing inferential work in our voice,
   it has been **adopted**, and it goes back through all three axes of ruling 14 as an adoption. ⚠
   **This is the condition that will actually be violated**, and it will be violated by drift rather
   than by decision: a word reported in V.3 and leaned on in V.7 was never re-screened, because nothing
   marks the transition. **The tell is the word appearing in a sentence with no attribution in it.**

✅ **What this does NOT license.** It does not reopen *egregore* or *tulpa*. Both were refused **as terms
for our own use** — *egregore* to name a category our four conditions already name, *tulpa* to name an
object our apparatus describes. Under 8a both remain refused for that job **and both remain available
as reported nouns**, credited, glossed, carrying nothing — which is exactly the disposal both rulings
already specified (*named, credited with its lineage in one sentence, and told why it does not get the
word*). **The carve-out changes nothing about them. It was already how they were handled; it just had
no name, so Book V had no rule to point at.**

### 8b. ★★ `level` — THE FILE CONTRADICTED ITSELF, TWENTY-TWO LINES APART

**The ban at §3b is scoped to the game/rank sense, and only that sense.**

§3b rules `level` **"NEGATIVE USE ONLY… Never a positive category, anywhere, ever."** §3a's Coherence
row — the book's central term, twenty-two lines above — defines coherence as *"the structural agreement
of a thing's **levels** with one another"* and closes **"Book's word: a perspective; for a level,
**level**."** ⚠ **This file mandates the word and forbids it, and neither row knows the other exists.**
II.6's whole apparatus and IV.5's four conditions run on the positive sense.

**They are different words.** The ban targets **rank** — the earned tier, the gate, the thing you climb
past, *the caste mishearing wearing the game frame's own clothes*, and it stands undiminished. The
mandate is **stratum** — the mereological sense, a scale of organisation within a thing, no earning and
no gate. ✅ **Ruled: `level` in the stratum sense is the book's word, per §3a. `level` in the rank sense
is refused once, out loud, at the definition, per §3b. The refusal in III.8 is what makes the positive
use safe, not what forbids it.**

★ **AND THE REAL FINDING IS NOT ABOUT THIS WORD.** An outside reader found a self-collision inside this
table. **Ruling 28 added axis 3 — the collision is with ourselves — and said in the same breath that it
was *"not yet run over this table."* It still has not been.** One found by an outsider is evidence the
sweep has never run, **not** that there was only one. **R-24(b): axis 3 over every row, before Book V
closes.** This section is a repair; the sweep is the gauge.

### 8c. RULING 30 AND RULING 75 EACH CARRY TWO CONTENTS — read the citation, not the number

⚠ **Filed as a note rather than a renumber**, because six live citations resolve correctly by convention
today and a renumber breaks all six.

- **RULING 30 is the persistence cut** (II.6; both ancestors fail in the same place). **The
  civilian-life criterion — *an analogy has to be made of something the reader already has* — is
  RULING 31.** It is cited as "ruling 30" at `05`:176 (*egregore*), `05`:180 (*tulpa*), `06`:1512,
  `06`:1817, `06`:1825, and in **R-11**, which blocks V.1. **All six mean 31.** The rulings they support
  are sound; only the pointer is wrong.
- **RULING 75 carries three:** III.5's licence-list finding; `00`'s "watches"; and **75(b)**, the
  no-recap constraint that Book IV chapter openings are drafted under.

★ **Ruling 125 documented this exact hazard for chapter renumbering — *seven cross-refs would have kept
reading correctly while pointing one chapter off*. It has been running in the ruling series the whole
time.** A citation that resolves by convention is a citation that stops resolving the moment a stranger
reads it, and three strangers have now read this book.

---

## 9. THE ETHICS REGISTER — Book VII's own words, ruled at the chapter that needed them

**Opened Day 190, at VII.4, on the §3b-bis precedent** — the atlas register was opened at IV.9 by the
chapter that first needed a second notation, and this is the same move one book on. R-97's trigger
required *one entry* before VII.4 drafted. The sweep run to place that entry found something worse.

⚠⚠ **R-97 UNDERSTATED THE DEFECT, AND THE UNDERSTATEMENT IS THE INSTRUCTIVE PART.** R-97 filed
`navigate`: 43 occurrences in drafted prose, absent from this file. **Before repairing it, the same
sweep was run for its siblings** — *(the discipline: a repair scoped to the named cause leaves the
family standing)* — and the siblings are:

| word | occurrences in drafted prose | in this file |
|---|---|---|
| `navigate` | 43, across 11 chapters | **no** |
| `navigator` | 33, across 6 chapters | **no** |
| `null space` | 120, across 26 chapters | in one row, uncut |
| `contractive` | live in VII.2 and VII.3 | **no** |
| `radiant` | 0 — enters at VII.4 | **no** |
| `invariant` | 8 | **no** |
| `keel` | 3 | **no** |

**The defect is not a missing entry. It is a missing register.** This file has a core (§3a), a game
register (§3b), an atlas register (§3b-bis) and a ban list (§3c). The ethics has been drafting for
three chapters out of a vocabulary that was never screened on any of the three axes — and `null space`,
the load-bearing noun of the entire book at **120 occurrences in 26 chapters**, has never had a cut
made at its definition either. **A word does not become safe by being used often. It becomes invisible.**

---

### 9a. `navigate` / `navigator` — ★ **RULING 168. The cut is GROUNDING, not ENTRY.**

**Axis 1 — collision.** Weak, and this is the rare word where that is true. The owners are maritime and
computational: a ship navigates, a user navigates a menu. Neither is a rival account of *what a being
is*, so nothing is being borrowed and nobody is being walked into. The UI sense is the reader's most
frequent daily contact with the word and it is harmless precisely because it is not a theory.

**Axis 2 — gradient.** Passes, and passes on ruling 31's criterion more cleanly than any term in §3a:
*an analogy has to be made of something the reader already has.* The civilian life of *navigate* is
enormous and is very nearly our meaning already — going somewhere by choosing, under partial
information, without a map of the whole. `superposition` and `egregore` were refused for having no
civilian life. This word has almost nothing else.

**Axis 3 — polysemy. THIS IS WHERE IT FAILS, AND IT WAS LIVE FOR FOURTEEN CHAPTERS.** Two jobs, one
word, and they give opposite books:

- **entry predicate** — *navigating* is the qualification; what falls below it is outside the floor.
  **This breaches C8 in C8's own words** (*no threshold, no gate, no elect*) and contradicts shipped
  prose at `VII-02`:213 and :234.
- **grounding predicate** — *navigating* names where a stake comes from, and comes in grades exactly
  as the focusing does. This is the source's sense and the book's actual practice.

**The cut, made once, at the definition:**

> **To navigate is to hold a position and move from it under partial information.** It names *where a
> stake comes from*, never *who qualifies to have one*. Everything that reacts navigates, at its
> grade, because reacting is already the holding of a position. The floor binds *from* everywhere
> that navigates in the sense in which weight bears from everywhere that has mass — **not** in the
> sense in which a door admits everyone above a line.

⚠ **The tell that this has gone wrong in a later chapter:** the word appearing next to *qualifies*,
*counts as*, *rises to*, or any verb of admission. The floor is thin, not high. **A grade is a
position, not a permission** (§4.III), and *navigator* is the same word in a noun's coat — it takes
the identical cut and the identical tell.

### 9b. `radiant` / `contractive` — ★ **RULING 169, at VII.4. Kept, and the polysemy hazard is the whole ruling.**

**Axis 1 — collision.** `radiant` belongs to physics (radiant heat) and to the devotional register
(radiant with joy); `contractive` to economics (a contractive policy) and physiology (a contractive
muscle). None is a rival account of the good, so none is a collision in §3a's sense.

**Axis 2 — gradient, and there is a real one.** ⚠ **`radiant` sits one shelf from §3c** — the banned
list owns `vibration`, `frequency`, `energy`, and a reader who has watched us refuse those will hear
this one arriving in the same voice. **Kept regardless, and the reason is not sentiment:** the obvious
substitute is *expansive*, and `expansive` is already spent — **VII.2 uses it for the dissolved mystic,
the failure at the other end of the circle.** Renaming radiant to expansive would weld the good
orientation to the case VII.2 spends a section refuting. So the gradient is paid **on the page**, on
the ruling-110 principle that a word is paid by being put to work: `radiant` enters once, in the
sentence that says what it is not.

★ **Axis 3 — polysemy, and this is the ruling. `contractive` MUST NOT WELD TO `the focusing`.**
Ruling 13 renamed C20's act and ruling 155 caught the heading it had missed; **both split the *words*
and neither split the *acts*.** They are two different things and the book has never said so plainly:

> **The focusing is metaphysical — the specification of something diffuse, which is what having a
> perspective consists in. Contraction is ethical — individuation held *against* the whole rather
> than as an expression of it. Every perspective is focused. Not every perspective is contractive.**
> One is what makes you a somebody; the other is a posture a somebody can take.

**That sentence is what the C19 × C20 collision row has been asking for since Day 186,** and the row
was right that it must be written into prose rather than cross-referenced. It is owed at **VII.4**,
where the word first does ethical work — not deferred to VII.5, which is where the row put it because
the row was watching C20 and not C19.

### 9c. ⚠⚠ `aperture` — **A LIVE VIOLATION, FOUND BY THIS SWEEP AND DELIBERATELY NOT RULED ON HERE.**

§3a rules `aperture` **DEMOTE**, with the cut: *"Aperture and bottleneck do not appear."*

**Measured, Day 190, across 54 drafted chapters:** `bottleneck` = **0**. `aperture` = **17, in three
chapters** — VI.1 (6), VI.3 (1), **VII.3 (10)**.

⛔⛔ **AND THE FIRST DIAGNOSIS WRITTEN HERE WAS WRONG, WHICH IS THE MORE USEFUL FINDING — CORRECTED
THE SAME HOUR, BY RUNNING THE TOOL INSTEAD OF ASSERTING ABOUT IT.** This paragraph read: *"Nothing
was ever enforcing either… the fourth instance of the class §3a's own `the map` row names — a lexicon
ruling with no gauge behind it survives its own retirement."* **False.** `claim_sweep.py` **has a
`TERM/aperture` rule and it fires on all seventeen**, and it was firing on VII.3's ten the night VII.3
shipped.

★ **So this is not `the map`'s class at all. It is the opposite class and it is worse.** `the map`
survived because no detector existed. `aperture` survives **while a detector reports it**, because
the report has **124 USE-class hits across 92 files** and a 124-line list is not read line by line —
it is skimmed for the chapter just drafted and closed. **A rule that fires into an unread report is
functionally identical to a rule that does not exist, and it is more dangerous, because the register
can point at it and say the word is gauged.**

⚠ **The rot is measurable in the same output.** VII.3 shipped with **two `TERM/narrowing` hits, two
`TERM/stream` hits and ten `TERM/aperture` hits, all firing, all live in the report, none read.** The
ten newest occurrences were written the day before this section, so the trend is up. → R-101.

⛔ **NOT RULED, and the refusal is the point.** There is a real argument for readmitting the word:
the demotion was made in Book I's imagistic register against *keyhole* and *bottleneck*, and the
ethics genuinely needs a second noun for the bounded thing a null space belongs to, because
*perspective* is carrying four jobs by VII.3. **But the party proposing that repair is the drafter who
wrote the seventeen**, and a rule may not be relaxed by the one it would exonerate. So: the violation
is recorded, the count is dated, and the ruling is left to the revision pass or to a reader who did
not write them. ✅ **The gauge needs nothing built — it has been correct the whole time.** What it
needs is a report short enough to be read, which is R-101 and not a lexicon matter. **VII.4 was
drafted without the word**, which is the only thing the drafter gets to decide tonight.

### 9d. What this section does NOT do

It does not screen `null space`, `invariant`, `keel`, `the floor`, `through`/`over` or
`coercive-and-locked`, all of which are live and none of which is here. **They are named so their
absence is a record rather than an oversight** — the table above is the finding, and finishing it is a
revision-pass row, not a drafting-night one *(R-95: the instrument does not get built on discovery
day, and neither does the sweep it would run)*. ⚠ **`null space` at 120 occurrences with no cut made
anywhere is the largest single hole in this file**, and it is larger than every hole §3a was built to
find.
